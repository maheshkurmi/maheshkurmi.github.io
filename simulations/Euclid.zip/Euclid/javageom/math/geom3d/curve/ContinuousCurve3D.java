/**
 * 
 */

package math.geom3d.curve;

/**
 * @author mahesh kurmi
 */
public interface ContinuousCurve3D extends Curve3D {

}
