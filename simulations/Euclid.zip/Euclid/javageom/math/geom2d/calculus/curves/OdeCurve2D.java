package math.geom2d.calculus.curves;

import gui.EuclideGui;

import org.lsmp.djep.djep.DJep;
import org.nfunk.jep.Node;

import dynamic.DynamicMeasure2D;

import math.geom2d.Point2D;
import math.geom2d.calculus.CalculusUtils;
import math.geom2d.line.LineSegment2D;

public class OdeCurve2D extends CurveExpr2D{
	protected DJep evaluatorX,evaluatorY ;
	protected String xExpr,yExpr;
	protected double x0=1,y0=1;

	/**
	 * Creates function as integration of given function from limit a to x
	 * @param f
	 */
	public OdeCurve2D(String xExpr,String yExpr, double x, double y){
		super();
		this.expr= xExpr + " ; " +yExpr;
		this.x0=x;
		this.y0=y;
		this.setExpression(xExpr,yExpr);
	}
	
	public Point2D getInitialPoint(){
		return new Point2D(x0,y0);
	}
	
	public void setInitialPoint(double x, double y){
		if (x < minX || y < minY || x > maxX || y > maxY)
			return;
		this.x0=x;
		this.y0=y;
		createCurve();
	}
	/**
	 * sets expression for the function
	 * 
	 * @param expr
	 * @return true if successfully parsed
	 */
	public boolean setExpression(String expr) {
		String[] s = expr.split(";");
		if (s.length >= 2) {
			setExpression(s[0], s[1]);
			return true;
		}
		return false;
	}

	public boolean setExpression(String xExpr, String yExpr) {
		try {
			isdefined = false;
			this.xExpr = xExpr.trim();
			xExpr=CalculusUtils.PreProcessExpression(this.xExpr);
			this.yExpr = yExpr.trim();
			yExpr=CalculusUtils.PreProcessExpression(this.yExpr);
			this.expr= this.xExpr + " ; " +this.yExpr;
			
			if (EuclideGui.getCurrentGui()==null || EuclideGui.getCurrentGui().getCurrentDoc()==null) return false;
			this.errInfo="";
			if(evaluatorX==null)evaluatorX = new DJep();
			EuclideGui.getCurrentGui().getCurrentDoc().updateParser(evaluatorX);
			evaluatorX.addVariable("x", 0);
			evaluatorX.addVariable("y", 0);
			
			Node node = evaluatorX.parseExpression(this.xExpr);
			errInfo = evaluatorX.getErrorInfo();
			if (errInfo!=null)throw new Exception(errInfo);
			
			if(evaluatorY==null)evaluatorY = new DJep();
			EuclideGui.getCurrentGui().getCurrentDoc().updateParser(evaluatorY);
			evaluatorY.addVariable("x", 0);
			evaluatorY.addVariable("y", 0);
	
			node = evaluatorY.parseExpression(this.yExpr);
			errInfo = evaluatorY.getErrorInfo();
			if (errInfo!=null)throw new Exception(errInfo);
		
			System.out.println("parsed OdeCurve2D :" + "dx="+this.xExpr +" ; dy="+ this.yExpr);
			
			isValidExpr=true;
			isdefined = true;
			createCurve();
			return true;
		} catch (Exception e) {
			errInfo = e.getMessage();
			isValidExpr=false;
			isdefined = false;
			return false;
		}

	}


     protected void createCurve(){
    	if (!isDefined())return;
    	this.clear();
 
		double h = max_t / num_steps;
		
		double k1, k2, k3, k4;
		double m1, m2, m3, m4;
		double x0, y0, x, y;
		x0 = this.x0;
		y0 = this.y0;
		for (int i = 1; i <= num_steps; i++) {
			evaluatorX.addVariable("x", x0);
			evaluatorX.addVariable("y", y0);
			evaluatorY.addVariable("x", x0);
			evaluatorY.addVariable("y", y0);
			k1 = evaluatorX.getValue();
			if (!isValidNumber(k1))break;
			m1 = evaluatorY.getValue();
			if (!isValidNumber(m1))break;
			evaluatorX.addVariable("x", x0 + h * k1 / 2);
			evaluatorX.addVariable("y", y0 + h * m1 / 2);
			evaluatorY.addVariable("x", x0 + h * k1 / 2);
			evaluatorY.addVariable("y", y0 + h * m1 / 2);
			k2 = evaluatorX.getValue();
			if (!isValidNumber(k2))break;
			m2 = evaluatorY.getValue();
			if (!isValidNumber(m2))break;
			evaluatorX.addVariable("x", x0 + h * k2 / 2);
			evaluatorX.addVariable("y", y0 + h * m2 / 2);
			evaluatorY.addVariable("x", x0 + h * k2 / 2);
			evaluatorY.addVariable("y", y0 + h * m2 / 2);
			k3 = evaluatorX.getValue();
			if (!isValidNumber(k3))break;
			m3 = evaluatorY.getValue();
			if (!isValidNumber(m3))break;
			evaluatorX.addVariable("x", x0 + h * k3);
			evaluatorX.addVariable("y", y0 + h * m3);
			evaluatorY.addVariable("x", x0 + h * k3);
			evaluatorY.addVariable("y", y0 + h * m3);
			k4 = evaluatorX.getValue();
			if (!isValidNumber(k4))break;
			m4 = evaluatorY.getValue();
			if (!isValidNumber(m4))break;
			x = x0 + h * (k1 + 2 * k2 + 2 * k3 + k4) / 6;
			y = y0 + h * (m1 + 2 * m2 + 2 * m3 + m4) / 6;
			LineSegment2D line=new LineSegment2D(x0,y0,x,y);
			if (!line.isEmpty()){
				this.add(new LineSegment2D(x0,y0,x,y));//path.lineTo(x, y);
			}
			if (x < minX || y < minY || x > maxX || y > maxY)
				break;
			x0 = x;
			y0 = y;
		}
		
		h = min_t / num_steps;
		
		x0 = this.x0;
		y0 = this.y0;
		for (int i = 1; i <= num_steps; i++) {
			evaluatorX.addVariable("x", x0);
			evaluatorX.addVariable("y", y0);
			evaluatorY.addVariable("x", x0);
			evaluatorY.addVariable("y", y0);
			k1 = evaluatorX.getValue();
			if (!isValidNumber(k1))break;
			m1 = evaluatorY.getValue();
			if (!isValidNumber(m1))break;
			evaluatorX.addVariable("x", x0 + h * k1 / 2);
			evaluatorX.addVariable("y", y0 + h * m1 / 2);
			evaluatorY.addVariable("x", x0 + h * k1 / 2);
			evaluatorY.addVariable("y", y0 + h * m1 / 2);
			k2 = evaluatorX.getValue();
			if (!isValidNumber(k2))break;
			m2 = evaluatorY.getValue();
			if (!isValidNumber(m2))break;
			evaluatorX.addVariable("x", x0 + h * k2 / 2);
			evaluatorX.addVariable("y", y0 + h * m2 / 2);
			evaluatorY.addVariable("x", x0 + h * k2 / 2);
			evaluatorY.addVariable("y", y0 + h * m2 / 2);
			k3 = evaluatorX.getValue();
			if (!isValidNumber(k3))break;
			m3 = evaluatorY.getValue();
			if (!isValidNumber(m3))break;
			evaluatorX.addVariable("x", x0 + h * k3);
			evaluatorX.addVariable("y", y0 + h * m3);
			evaluatorY.addVariable("x", x0 + h * k3);
			evaluatorY.addVariable("y", y0 + h * m3);
			k4 = evaluatorX.getValue();
			if (!isValidNumber(k4))break;
			m4 = evaluatorY.getValue();
			if (!isValidNumber(m4))break;
			x = x0 + h * (k1 + 2 * k2 + 2 * k3 + k4) / 6;
			y = y0 + h * (m1 + 2 * m2 + 2 * m3 + m4) / 6;
			LineSegment2D line=new LineSegment2D(x0,y0,x,y);
			if (!line.isEmpty()){
				this.add(new LineSegment2D(x0,y0,x,y));//path.lineTo(x, y);
			}
			if (x < minX || y < minY || x > maxX || y > maxY)
				break;
			x0 = x;
			y0 = y;
		}

	}

	@Override
	protected Point2D getPoint(double t) {
		return point(t);
	}

	@Override
	public CurveType getCurveType() {
		return CurveType.ODE;
	}

	public boolean setCurve(CurveExpr2D curve){
		if (this.getClass()!=curve.getClass())return false;
		this.min_t=curve.min_t;
		this.max_t=curve.max_t;
		this.minX=curve.minX;
		this.maxX=curve.maxX;
		this.minY=curve.minY;
		this.maxY=curve.maxY;
		this.x0=((OdeCurve2D) curve).getInitialPoint().x;
		this.y0=((OdeCurve2D) curve).getInitialPoint().y;
		return this.setExpression(curve.getExpression());

	}
}
