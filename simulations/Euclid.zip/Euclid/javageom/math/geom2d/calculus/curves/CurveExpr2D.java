package math.geom2d.calculus.curves;

import math.geom2d.Box2D;
import math.geom2d.Point2D;
import math.geom2d.calculus.Plottable2D;
import math.geom2d.curve.CurveArray2D;
import math.geom2d.line.LineSegment2D;

/**
 * base class to facilitate polar, parametric and ode curves
 * @author mahesh
 *
 */
public abstract class CurveExpr2D extends CurveArray2D<LineSegment2D> implements Plottable2D {

	protected String expr, xExpr, yExpr;
	protected double min_t = -10, max_t = 10;
	protected int num_steps = 180;

	/** stores error why curve is not defined */
	protected String errInfo = "";
	/** Flag to check if ode is defined or not */
	protected boolean isdefined = false;

	/** domain of function */
	protected double minX = -10;
	protected double maxX = +10;

	/** clipped range of function */
	protected double minY = -10;
	protected double maxY = +10;

	/** Flag to check if expression of function is valid */
	protected boolean isValidExpr = false;

	/**
	 * returns true if function is defined i.e. is nonEmpty having valid domain
	 * and range
	 * 
	 * @return
	 */
	public boolean isDefined() {
		if (!isdefined)
			return false;

		if ((errInfo == null) || (errInfo == ""))
			return true;
		else
			return false;
	}

	/**
	 * returns true if expression of f(x) is parsable
	 * 
	 * @return
	 */
	public boolean isValidExpr() {
		return isValidExpr;
	}

	/**
	 * returns error if any in defining function it includes parser error and
	 * domain error
	 * 
	 * @return
	 */
	public String getErrInfo() {
		return errInfo;
	}

	@Override
	public Box2D boundingBox() {
		if (!this.isdefined)
			return null;
		return new Box2D(minX, maxX, minY, maxY);
	}

	/**
	 * clips curve against box
	 * 
	 * @param box
	 */
	public void setBounds(Box2D box) {
		if (this.minX != box.getMinX() || this.minY != box.getMinY()
				|| this.maxX != box.getMaxX() || this.maxY != box.getMaxY()) {
			this.minX = box.getMinX();
			this.minY = box.getMinY();
			this.maxX = box.getMaxX();
			this.maxY = box.getMaxY();
			createCurve();
		}

	}

	/**
	 * returns expression for the curve
	 * @return the expr
	 */
	public String getExpression() {
		return expr;
	}

	/**
	 * returns minimum value of parameter t
	 * @return
	 */
	public double getMinT() {
		return min_t;
	}

	/**
	 * returns maximum value of parameter t
	 * @return
	 */
	public double getMaxT() {
		return max_t;
	}

	/**
	 * returns minimum value of parameter t
	 * @return
	 */
	public void setMinT(double t) {
		 min_t=t;
	}

	/**
	 * returns maximum value of parameter t
	 * @return
	 */
	public void setMaxT(double t) {
		 max_t=t;
	}
	/**
	 * sets min and max value of parameter t
	 * @param mint
	 * @param maxt
	 */
	public void set_t(double mint, double maxt) {
		min_t = Math.min(mint, maxt);
		max_t = Math.max(mint, maxt);
	}
	
	
	public static boolean isValidNumber(double d) {
		if (Double.isInfinite(d) || Double.isNaN(d))
			return false;
		return true;

	}

	/**
	 * sets expression for the function
	 * 
	 * @param expr
	 * @return true if successfully parsed
	 */
	public abstract boolean setExpression(String expr);

	/**
	 * Create Curve by adding linesegments defining this curve
	 */
	protected abstract void createCurve();

	/**
	 * returns a point corressponding to parameter t on this curve
	 * @param t
	 * @return point on curve for parameter t, returns null if point is not defined or lies outside clipped box of curve
	 */
	protected abstract Point2D getPoint(double t);
	
	/**
	 * returns {@CurveType}  of this curve
	 * @return
	 */
	public abstract CurveType getCurveType();
	
	public boolean setCurve(CurveExpr2D curve){
		if (this.getClass()!=curve.getClass())return false;
		this.min_t=curve.min_t;
		this.max_t=curve.max_t;
		this.minX=curve.minX;
		this.maxX=curve.maxX;
		this.minY=curve.minY;
		this.maxY=curve.maxY;
		return this.setExpression(curve.getExpression());
	}
	  /**
     * The different types of Function Combination mode.
     */
    public enum CurveType {
        /** Polar curve r =f(t)*/
        POLAR,
        /** Paramteric curve x=f(t), y=g(t) */
        PARAMETRIC,
        /** ODE dy=f(x,y), dx=g(x,y) */
        ODE,
        /** Implicit f(x,y)=0*/
        IMPLICIT_CARTESIAN,
        /**Implicit polar f(r,t)=0 */
        IMPLICIT_POLAR,
        /** unknown type of curve*/
        UNKNOWN

     }
    

}
