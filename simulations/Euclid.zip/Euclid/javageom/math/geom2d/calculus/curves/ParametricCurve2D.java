package math.geom2d.calculus.curves;

import gui.EuclideGui;

import org.lsmp.djep.djep.DJep;
import org.nfunk.jep.Node;

import dynamic.DynamicMeasure2D;
import math.geom2d.Point2D;
import math.geom2d.calculus.CalculusUtils;
import math.geom2d.line.LineSegment2D;

public class ParametricCurve2D extends CurveExpr2D{
	protected DJep evaluatorX,evaluatorY ;
	protected String xExpr,yExpr;
	/**
	 * Creates function as integration of given function from limit a to x
	 * @param f
	 */
	public ParametricCurve2D(String xExpr,String yExpr, double mint, double maxt){
		super();
		this.min_t=mint;
		this.max_t=maxt;
		num_steps=(int) Math.min(200, Math.max(10,10*(maxt-mint)));
		num_steps=100;
		this.expr= xExpr + " ; " + yExpr;
		this.setExpression(xExpr,yExpr);
		createCurve();
	}
	
	/**
	 * Creates function as integration of given function from limit a to x
	 * @param f
	 */
	public ParametricCurve2D(String expr, double mint, double maxt){
		super();
		this.min_t=mint;
		this.max_t=maxt;
		this.expr= xExpr + " ; " + yExpr;
		this.setExpression(xExpr,yExpr);
		createCurve();
	}
	
	/**
	 * Creates function as integration of given function from limit a to x
	 * @param f
	 */
	public ParametricCurve2D(String xExpr,String yExpr){
		super();
		this.expr= xExpr + " ; " + yExpr;
		this.setExpression(xExpr,yExpr);
		createCurve();
	}
	
	@Override
	public String toString(){
		return "x(t)=" + xExpr + " ; y(t)=" + yExpr ; 
	}
	
	
	/**
	 * sets expression for the function
	 * 
	 * @param expr
	 * @return true if successfully parsed
	 */
	public boolean setExpression(String expr) {
		String[] s = expr.split(";");
		if (s.length == 2) {
			setExpression(s[0], s[1]);
			return true;
		}
		return false;
	}

	public boolean setExpression(String xExpr, String yExpr) {
		try {
			this.xExpr = CalculusUtils.PreProcessExpression(xExpr);
			this.yExpr = CalculusUtils.PreProcessExpression(yExpr);
			this.expr= xExpr + " ; " + yExpr;
			
			if (EuclideGui.getCurrentGui()==null || EuclideGui.getCurrentGui().getCurrentDoc()==null) return false;
			this.errInfo="";
			if(evaluatorX==null)evaluatorX = new DJep();
			EuclideGui.getCurrentGui().getCurrentDoc().updateParser(evaluatorX);
			evaluatorX.addVariable("t", 0);
			Node node = evaluatorX.parseExpression(this.xExpr);
			errInfo = evaluatorX.getErrorInfo();
			if (errInfo!=null)throw new Exception(errInfo);
	
			if(evaluatorY==null)evaluatorY = new DJep();
			EuclideGui.getCurrentGui().getCurrentDoc().updateParser(evaluatorY);
			evaluatorY.addVariable("t", 0);
			node = evaluatorY.parseExpression(this.yExpr);
			errInfo = evaluatorY.getErrorInfo();
			if (errInfo!=null)throw new Exception(errInfo);
	
			System.out.println("parsed Parametric Curve2D :" +  "x="+xExpr +" ; y="+yExpr);

			isdefined = true;
			return true;
		} catch (Exception e) {
			errInfo = e.getMessage();
			isdefined = false;
			return false;
		}

	}

	@Override
	public Point2D getPoint(double t) {
		double x, y;
		evaluatorX.addVariable("t", t);
		x = evaluatorX.getValue();
		if (!isValidNumber(x))
			return null;
		evaluatorY.addVariable("t", t);
		y = evaluatorY.getValue();
		if (!isValidNumber(y))
			return null;
		if (x < minX-1 || y < minY-1 || x > maxX+1 || y > maxY+1)
			return null;

		return new Point2D(x, y);
	}
	
	@Override
     protected void createCurve(){
    	if (!isDefined())return;
    	this.clear();
 
		double t1,t2;
			
		for (int i = 0; i <= num_steps-1; i++) {
			t1 = min_t + (max_t - min_t) * i / num_steps;
			Point2D p1=getPoint(t1);
			if (p1==null)continue;
			t2 = min_t + (max_t - min_t) * (i+1) / num_steps;
			Point2D p2=getPoint(t2);
			if (p2==null)continue;
			if (p1.almostEquals(p2, ACCURACY))continue;
			
			LineSegment2D line=new LineSegment2D(p1,p2);
			this.add(line);
		}
	

	}
	
	@Override
	public CurveType getCurveType() {
		return CurveType.PARAMETRIC;
	}


}
