package math.geom2d.calculus.curves;

import gui.EuclideGui;

import java.util.logging.Logger;

import org.lsmp.djep.djep.DJep;
import org.nfunk.jep.Node;

import dynamic.DynamicMeasure2D;
import math.geom2d.Point2D;
import math.geom2d.Shape2D;
import math.geom2d.calculus.CalculusUtils;
import math.geom2d.line.LineSegment2D;
import math.geom3d.Vector3D;

public class ImplicitCurve2D extends CurveExpr2D{
	protected DJep evaluator ;
	/**no of divisions/grids for surface*/
	private int xGrids = 100, yGrids = 100;
	/**Type of function  Polar and Cartesian*/
	private boolean isPolar=false;
	
	/**
	 * Creates implicit function (default is Cartesian f(x,y)=0
	 */
	public ImplicitCurve2D(){
		super();
	}
	/**
	 * Creates implicit function (default is Cartesian f(x,y)=0
	 * @param f expression of for f(x,y)=0
	 */
	public ImplicitCurve2D(String expr){
		super();
		this.setExpression(expr);
	}
	
	@Override
	public String toString(){
		return expr+ " = 0"; 
	}
	
	/**
	 * Creates Implicit function
	 * @param expr
	 * @param mint
	 * @param maxt
	 * @param isPolar
	 */
	public ImplicitCurve2D(String expr, double mint, double maxt, boolean isPolar){
		super();
		this.min_t=mint;
		this.max_t=maxt;
		this.minX=mint;
		this.maxX=maxt;
		this.minY=mint;
		this.maxY=maxt;
		
		this.setExpression(expr);
		this.isPolar=isPolar;
	}
	
	
	/**
	 * sets expression for the function
	 * 
	 * @param expr
	 * @return true if successfully parsed
	 * */

	public boolean setExpression(String expr) {
		this.expr=expr;
		try {
			String[] temp;
			String exprNew;
			temp=expr.split("=");
			switch (temp.length)
			{
			case 1:
				exprNew=expr;
				break;
			case 2:
				exprNew=temp[0].trim()+"-("+temp[1].trim()+")";
				break;
			default:
				throw new Exception("Syntax Error");
			}
			
			if (EuclideGui.getCurrentGui()==null || EuclideGui.getCurrentGui().getCurrentDoc()==null) return false;
			this.errInfo="";

			String s = CalculusUtils.PreProcessExpression(exprNew);
			this.expr=exprNew;
			if(evaluator==null)evaluator = new DJep();
			EuclideGui.getCurrentGui().getCurrentDoc().updateParser(evaluator);
			
			if (!isPolar){
				evaluator.addVariable("x", 0);
				evaluator.addVariable("y", 0);
			}else{
				evaluator.addVariable("r", 0);
				evaluator.addVariable("t", 0);
			}
			
			Node node = evaluator.parseExpression(s);
			errInfo = evaluator.getErrorInfo();
			if (errInfo!=null)throw new Exception(errInfo);
	
			System.out.println("parsed Implicit2D :" + s);
			isdefined = true;
			createCurve();
			return true;
		} catch (Exception e) {
			errInfo = e.getMessage();
			isdefined = false;
			return false;
		}

	}

	public int getxGrids() {
		return xGrids;
	}

	public void setxGrids(int xGrids) {
		if (xGrids > 0)
			this.xGrids = xGrids;
		else
			Logger.getLogger(ImplicitCurve2D.class.getName()).info("Illegral number of ygrids" + yGrids);
	}

	public int getyGrids() {
		return yGrids;
	}

	public void setyGrids(int yGrids) {
		if (yGrids > 0)
			this.yGrids = yGrids;
		else
			Logger.getLogger(ImplicitCurve2D.class.getName()).info("Illegral number of ygrids" + yGrids);
	}

	private double f(double x, double y) {
		double z=Double.NaN;
		if (!isPolar){
			evaluator.setVarValue("x", x);
			evaluator.setVarValue("y", y);
			z=evaluator.getValue();
		}else{
			double r=Math.sqrt(x*x+y*y);
			double t=Math.atan2(y, x);
			evaluator.setVarValue("r", r);
			evaluator.setVarValue("t", t);
			z=evaluator.getValue();
		}
		return z;
	}
	
	@Override
	protected Point2D getPoint(double t) {
		return point(t);
	}
	
     protected void createCurve(){
    	if (!isDefined())return;
    	this.clear();
 		double dx,dy;
		dx=(maxX-minX)/xGrids;
		dy=(maxY-minY)/yGrids;
		for (double x = minX; x < maxX-dx; x +=dx) {
			for (double y = minY; y < maxY-dy; y += dy) {
					Vector3D[] vertices=new Vector3D[4];
					double[] values= new double[4];
					double x1,y1;
					x1=x;y1=y;
					vertices[0]=new Vector3D(x1,y1,0);
					values[0]= f(x1,y1);
					x1=x;y1=y+dy;
					vertices[1]=new Vector3D(x1,y1,0);
					values[1]= f(x1,y1);
					x1=x+dx;y1=y+dy;
					vertices[2]=new Vector3D(x1,y1,0);
					values[2]= f(x1,y1);
					x1=x+dx;y1=y;
					vertices[3]=new Vector3D(x1,y1,0);
					values[3]= f(x1,y1);
				
                    GRID grid =new GRID();
                    grid.p=vertices;
                    grid.val=values;
                    Polygonise(grid,0);
			}
		}
	}

     /*
 	 * Given a grid cell and an isolevel, calculate the triangular facets
 	 * required to represent the isosurface through the cell. Return the number
 	 * of triangular facets, the array "triangles" will be loaded up with the
 	 * vertices at most 5 triangular facets. 0 will be returned if the grid cell
 	 * is either totally above of totally below the isolevel.
 	 */
 	public int Polygonise(GRID grid, double isolevel) {
 		int i, nlines;
 		int squareindex;
 		Vector3D[] vertlist = new Vector3D[4];
 		// For any edge, if one vertex is inside of the surface and the other is outside of the surface
 	//  then the edge intersects the surface
 	// For each of the 4 vertices of the cube can be two possible states : either inside or outside of the surface
 	// For any cube the are 2^8=256 possible sets of vertex states
 	// This table lists the edges intersected by the surface for all 256 possible vertex states
 	// There are 12 edges.  For each entry in the table, if edge #n is intersected, then bit #n is set to 1
 		int[] edgeTable ={0x0,  0x9,  0x3,  0xa,  
 				          0x6,  0xf, 0x5,  0xc, 
 				          0xc, 0x5,  0xf, 0x6,
 				          0xa, 0x3,  0x9,  0x0};
 	
 	//  For each of the possible vertex states listed in aiCubeEdgeFlags there is a specific triangulation
 	//  of the edge intersection points.  a2iTriangleConnectionTable lists all of them in the form of
 	//  0-5 edge triples with the list terminated by the invalid value -1.
 	//  For example: a2iTriangleConnectionTable[3] list the 2 triangles formed when corner[0] 
 	//  and corner[1] are inside of the surface, but the rest of the cube is not.
 	//
 		int[][] lineTable = {
 				{ -1, -1, -1, -1 },
 				{  3,  0, -1, -1 },
 				{  0,  1, -1, -1 },
 				{  3,  1, -1, -1 },
 				{  2,  1, -1, -1 },
 				{  3,  2,  1,  0 },
 				{  2,  0, -1, -1 },
 				{  3,  2, -1, -1 },
 				{  3,  2, -1, -1 },
 				{  2,  0, -1, -1 },
 				{  3,  2,  1,  0 },
 				{  2,  1, -1, -1 },
 				{  3,  1, -1, -1 },
 				{  1,  0, -1, -1 },
 				{  3,  0, -1, -1 },
 				{ -1, -1, -1, -1 }    };
 				

 		/*
 		 * Determine the index into the edge table which tells us which vertices
 		 * are inside of the surface
 		 */
 		squareindex = 0;
 		if (grid.val[0] < isolevel)
 			squareindex |= 1;
 		if (grid.val[1] < isolevel)
 			squareindex |= 2;
 		if (grid.val[2] < isolevel)
 			squareindex |= 4;
 		if (grid.val[3] < isolevel)
 			squareindex |= 8;
 		
 		/* Cube is entirely in/out of the surface */
 		if (edgeTable[squareindex] == 0)
 			return (0);

 		/* Find the vertices where the surface intersects the cube */
 		if ((edgeTable[squareindex] & 1) != 0)
 			vertlist[0] = VertexInterp(isolevel, grid.p[0], grid.p[1],
 					grid.val[0], grid.val[1]);
 		if ((edgeTable[squareindex] & 2) != 0)
 			vertlist[1] = VertexInterp(isolevel, grid.p[1], grid.p[2],
 					grid.val[1], grid.val[2]);
 		if ((edgeTable[squareindex] & 4) != 0)
 			vertlist[2] = VertexInterp(isolevel, grid.p[2], grid.p[3],
 					grid.val[2], grid.val[3]);
 		if ((edgeTable[squareindex] & 8) != 0)
 			vertlist[3] = VertexInterp(isolevel, grid.p[3], grid.p[0],
 					grid.val[3], grid.val[0]);
 		
 		/* Create the curvesegments */
 		nlines = 0;
		Point2D p1,p2;
				 
 		for (i = 0; (lineTable[squareindex][i] != -1); i += 2) {
 			p1=new Point2D(vertlist[lineTable[squareindex][i]].getX(),vertlist[lineTable[squareindex][i]].getY());
 			p2=new Point2D(vertlist[lineTable[squareindex][i+1]].getX(),vertlist[lineTable[squareindex][i+1]].getY());
 			if (p1.almostEquals(p2, Shape2D.ACCURACY))continue;
 			LineSegment2D line = new LineSegment2D(p1,p2);
 			this.add(line);
 			if (i>=2)break;
 			nlines++;
 		}
 		return (nlines);
 	}

 	/*
 	 * Linearly interpolate the position where an isosurface cuts an edge
 	 * between two vertices, each with their own scalar value
 	 */
 	Vector3D VertexInterp(double isolevel, Vector3D p1, Vector3D p2,
 			double valp1, double valp2)
 	{
 		double mu;
 		Vector3D p;

 		if (Math.abs(isolevel - valp1) < 0.00001)
 			return (p1);
 		if (Math.abs(isolevel - valp2) < 0.00001)
 			return (p2);
 		if (Math.abs(valp1 - valp2) < 0.00001)
 			return (p1);
 		mu = (isolevel - valp1) / (valp2 - valp1);
 		p = Vector3D.intepolate(p1, p2, mu);
 		p.setX(p1.getX() + mu * (p2.getX() - p1.getX()));
 		p.setY(p1.getY() + mu * (p2.getY() - p1.getY()));
 		p.setZ(p1.getZ() + mu * (p2.getZ() - p1.getZ()));

 		return (p);
 	}

 	/**
 	 * @return the funcType
 	 */
 	public boolean isPolar() {
 		return isPolar;
 	}

 

 	 class GRID {
 		  public Vector3D[] p=new Vector3D[4];
 		  public double[] val=new double[4];
 	}

	@Override
	public CurveType getCurveType() {
		if (isPolar)
			return CurveType.IMPLICIT_POLAR;
		else
			return CurveType.IMPLICIT_CARTESIAN;
	}		
}
