package math.geom2d.calculus.curves;

import gui.EuclideGui;

import org.lsmp.djep.djep.DJep;
import org.nfunk.jep.Node;

import dynamic.DynamicMeasure2D;
import math.geom2d.Point2D;
import math.geom2d.calculus.CalculusUtils;
import math.geom2d.line.LineSegment2D;

public class PolarCurve2D extends CurveExpr2D{
	protected DJep evaluator ;
	
	/**
	 * Creates function as integration of given function from limit a to x
	 * @param f
	 */
	public PolarCurve2D(){
		super();
		min_t=0;
		max_t=2*Math.PI;
	}
	/**
	 * Creates function as integration of given function from limit a to x
	 * @param f
	 */
	public PolarCurve2D(String expr){
		this();
		this.setExpression(expr);
	}
	
	@Override
	public String toString(){
		return "r(t) ="+expr;
	}
	
	/**
	 * Creates function as integration of given function from limit a to x
	 * @param f
	 */
	public PolarCurve2D(String expr, double mint, double maxt){
		super();
		this.min_t=mint;
		this.max_t=maxt;
		num_steps=Math.min(360, Math.max(10,(int) Math.toDegrees(maxt-mint)));
		this.setExpression(expr);
	}
	
	
	/**
	 * sets expression for the function
	 * 
	 * @param expr
	 * @return true if successfully parsed
	 * */

	public boolean setExpression(String expr) {
		this.expr=expr;
		
		try {
			if (EuclideGui.getCurrentGui()==null || EuclideGui.getCurrentGui().getCurrentDoc()==null) return false;
			this.errInfo="";
			String s = CalculusUtils.PreProcessExpression(expr);

			if(evaluator==null)evaluator = new DJep();
			EuclideGui.getCurrentGui().getCurrentDoc().updateParser(evaluator);
			evaluator.addVariable("t", 0);
		
			Node node = evaluator.parseExpression(this.expr);
			errInfo = evaluator.getErrorInfo();
			if (errInfo!=null)throw new Exception(errInfo);
	
			System.out.println("parsed Polar2D :" +s);

			isdefined = true;
			createCurve();
			return true;
		} catch (Exception e) {
			errInfo = e.getMessage();
			isdefined = false;
			return false;
		}

	}

	@Override
	protected Point2D getPoint(double t) {
		evaluator.addVariable("t", t);
		double r=evaluator.getValue();
		if (!isValidNumber(r))return null;
		double x=r*Math.cos(t);
		double y=r*Math.sin(t);
		if (x < minX || y < minY || x > maxX || y > maxY)
			return null;
		return new Point2D(x,y);
	}
	
	@Override
    protected void createCurve(){
    	if (!isDefined())return;
    	this.clear();
		double t1,t2;
			
		for (int i = 0; i < num_steps-1; i++) {
			
			t1 = min_t + (max_t - min_t) * i / num_steps;
			Point2D p1=getPoint(t1);
			if (p1==null)continue;
			
			t2 = min_t + (max_t - min_t) * (i+1) / num_steps;
			Point2D p2=getPoint(t2);
			if (p2==null)continue;
			
			if (p1.almostEquals(p2, ACCURACY))continue;
			LineSegment2D line=new LineSegment2D(p1,p2);
			this.add(line);
		}
	
	}

	@Override
	public CurveType getCurveType() {
		return CurveType.POLAR;
	}

}
