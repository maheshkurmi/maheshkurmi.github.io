package math.geom2d.calculus;

/**
 * Interfacce for Curves/ functions which can be plotted using expression
 * @author mahesh
 *
 */
public interface Plottable2D {

	/**
	 * returns expression for this plottable
	 * @return
	 */
	public String getExpression();
	
	/**
	 * Sets expression for this plottable
	 * @return true if expression is successfully parsed
	 */
	public boolean setExpression(String expr);
	
	
	/**
	 * return true if this plottable is defined means non empty, contains something to plot
	 * resons for not defined may be due to invalid range of inputs or unparsable expressions
	 * @return
	 */
	public boolean isDefined();
	
	/**
	 * returns true if expression of this plottable is parsable
	 * @return
	 */
	public boolean isValidExpr();
	

	/**
	 * returns error if any in defining function it includes parser error and domain error
	 * @return
	 */
	public String getErrInfo();
	
	/**
	 * returns String representation of this plottable
	 * @return
	 */
	public String toString();
	
}
