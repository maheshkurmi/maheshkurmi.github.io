package math.geom2d.calculus;

import gui.EuclideGui;

import java.util.ArrayList;

import math.geom2d.calculus.function.DiffFunction2D;
import math.geom2d.calculus.function.Function2D;
import math.geom2d.calculus.function.IntegrationFunction2D;
import math.geom2d.calculus.function.PieceWiseFunction2D;

import org.lsmp.djep.djep.DJep;
import org.lsmp.djep.xjep.PrintVisitor;
import org.nfunk.jep.Node;
import org.nfunk.jep.ParseException;

public class CalculusUtils {

	/**
	 * Tries to differentiate the function using symbolic differentiator and 
	 * creates a function with result as expression. If it can't find symbolic derivative then it 
	 * returns diffFunction2D object (a numerical differentiator)
	 * @param f
	 * @return Function representing derivative of function
	 */
	public static Function2D createDerivativeFunction(Function2D f) {
		if(f instanceof IntegrationFunction2D){
			String expr=((IntegrationFunction2D)f).getBaseFunction().getExpression();
			return new Function2D(expr,f.minX,f.maxX);
		}
		if (f instanceof PieceWiseFunction2D){
			PieceWiseFunction2D pf=(PieceWiseFunction2D) f;
			ArrayList<Function2D> funcList=new ArrayList<Function2D>(pf.funcList.size());
			for (Function2D func:pf.funcList){
				Function2D df=createDerivativeFunction(func);
				df.setMin(func.minX, false);//func.isDifferentiableAt(func.minX));
				df.setMax(func.maxX, pf.isDifferentiableAt(func.maxX));
				funcList.add(df);
			}
			PieceWiseFunction2D returnf= new PieceWiseFunction2D(funcList);
			return returnf;
		}
		if (f instanceof IntegrationFunction2D){
			return new DiffFunction2D(f);
		}
		
		DJep evaluator;
		try {
			evaluator = new DJep();
			evaluator.addStandardConstants();
			evaluator.addStandardFunctions();
			evaluator.setAllowUndeclared(true);
			evaluator.setAllowAssignment(true);
			evaluator.setImplicitMul(true);
			evaluator.addStandardDiffRules();
			
			// parse the string
			String s = CalculusUtils.PreProcessExpression(f.getExpression());
			Node node = evaluator.parse(s);
			Node simp1 = evaluator.simplify(node);

			// differentiate wrt x
			Node diff = evaluator.differentiate(simp1, f.variable);
			evaluator.println(diff);
			// simplify
			Node simp2 = evaluator.simplify(diff);
			// print
			s = simp2.toString();
			PrintVisitor pv = new PrintVisitor();
			// pv.print(simp);
			s = pv.toString(simp2);
			evaluator.parseExpression(s);
			Function2D df= new Function2D(s, f.minX, f.maxX);
			df.setMin(f.minX, f.leftClosed);
			df.setMax(f.maxX, f.rightClosed);
			evaluator=null;
			return  df;
		} catch (ParseException e) {
			evaluator=null;
			return new DiffFunction2D(f);
		}
	}


	/**
	 * removes [ ] by floor(), { } by frac(), | | by abs()
	 * 
	 * @param string
	 *            string representing expression
	 * @return String representing expression after replacing [],{} and ||
	 */
	public static String PreProcessExpression(String str) {
		String exp;
		
		StringBuilder strB = new StringBuilder(str);
		exp = strB.toString();
		exp = exp.replace("[", "(floor(");
		exp = exp.replace("]", "))");
		exp = exp.replace("{", "(frac(");
		exp = exp.replace("}", "))");

		exp=removeMod(exp);
		exp=replaceLog(exp);
		return exp;

	}

	
	private static String removeMod(String str) {
	
		StringBuilder strB = new StringBuilder(str);
	
		//replace Mod symbol by < if occurs at first index
		if (strB.charAt(0) == '|')	
			strB.replace(0, 1, "<");
		//replace Mod symbol by > if occurs at last index
		if (strB.charAt(strB.length()-1) == '|')
			strB.replace(strB.length()-1, strB.length(), ">");
 
        //check for more mod symbols if any
		//if mod Symbol is preceded by operator it must be starting mod [
		//else it must be ending mod (HOPE SO........)
		for (int i = 1; i < strB.length() - 1; i++) {
			if (strB.charAt(i)=='|'){
				//check if char left to | is operator
				if (isOperator(strB.charAt(i - 1))) {
					//replace | by <
                    strB.replace(i, i+1, "<");
				} else {
					//replace | by >, since char to right of it is operator
					strB.replace(i, i+1, ">");
				}
			}	
		}		
		str=strB.toString();
		//replace open mode < by "abs(" and closing mod > by ")"
		str=str.replace("<","abs((");
		str=str.replace(">","))");
		//System.out.println(strB + "==" + str);
		return str;
		
	}

	private static String replaceLog(String exp){
		exp = exp.replace("log10(", "log[");
		exp = exp.replace("log(", "ln(");
		exp = exp.replace("log[", "log(");
		return exp;
	}
	
	private static boolean isOperator(char c) {

		switch (c) {
		case '/':
			return true;
		case '+':
			return true;
		case '-':
			return true;
		case '*':
			return true;
		case '(':
			return true;
		case ')':
			return true;
		case '<':
			return true;
		case ',':
			return true;
		default:
			return false;
		}

	}
}
