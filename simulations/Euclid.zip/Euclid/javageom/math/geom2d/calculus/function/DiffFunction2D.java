package math.geom2d.calculus.function;

public class DiffFunction2D extends Function2D{

	protected Function2D baseFunction;
	
	/**
	 * Creates function as derivative of given function. It tries to differentiate function using parser
	 * and then sets expression as resulting derivative string else it finds derivative by using definition of derivative
	 * @param f
	 */
	public DiffFunction2D(Function2D f){
		super();
		this.minX=f.minX;
		this.maxX=f.maxX;
		leftClosed=false;
		rightClosed=false;
		this.baseFunction=f;
		this.isdefined=f.isdefined;
		isValidExpr=false;
		expr="d/dx( "+f.getExpression() +" )";
	}
	
	/*
	@Override
	public void reCalculate(double clipMinX,double clipMaxX){
		this.minX=baseFunction.minX;
		this.maxX=baseFunction.maxX;
		this.isdefined=baseFunction.isdefined;
		isValidExpr=false;
		expr="d/dx( "+baseFunction.getExpression() +" )";
		super.reCalculate(clipMinX,clipMaxX);
	}
	*/

	@Override()
	public double getY(double x){
		if (!this.isdefined) return Double.NaN;
		if (!isInDomain(x)) return Double.NaN;
		return baseFunction.getDerivative(x);
	}
	
	@Override
	public DiffFunction2D subCurve(double t0, double t1) {
		if (t0< this.minX || t1>this.maxX) return null;
		Function2D f=this.baseFunction.subCurve(t0, t1);
		return new DiffFunction2D(f);
	}

}
