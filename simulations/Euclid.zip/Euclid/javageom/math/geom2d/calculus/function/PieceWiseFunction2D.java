package math.geom2d.calculus.function;

import java.awt.geom.AffineTransform;
import java.awt.geom.GeneralPath;
import java.awt.geom.Path2D;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Collections;

import math.geom2d.Box2D;
import math.geom2d.Dot2D;

public class PieceWiseFunction2D extends Function2D{

	public ArrayList<Function2D> funcList;
	
	
	public PieceWiseFunction2D(String expr, double minX,double maxX){
		super();
		this.minX=minX;
		this.maxX=maxX;
		//expr.treplace("\n", " ; ");
		this.expr=expr;
		
		funcList=new ArrayList<Function2D>();
	}
	
	public PieceWiseFunction2D(ArrayList<Function2D> funcList){
		super();
		this.expr="";
		this.isValidExpr=false;
		if (funcList.size()<1){
			this.isdefined=false;
			return;
		}
		this.minX=funcList.get(0).minX;
		this.maxX=funcList.get(0).maxX;
		
		for(Function2D f:funcList){
			if (!f.isDefined()){
				this.isdefined=false;
				this.expr="";
				return;
			}
			this.expr=this.expr+f.toString()+" ; ";
			this.minX=Math.min(minX,f.minX);
			this.maxX=Math.min(maxX,f.maxX);
		}
		this.funcList=funcList;

		this.isdefined=true;
	}
	
	@Override
	public String toString(){
		String str="";
		for(Function2D func:funcList){
			str=str+func.toString()+"; ";
		}
		return str;
	}
	
	/*
	@Override
	public void reCalculate(double clipMinX,double clipMaxX){
		this.minX=clipMinX;
		this.maxX=clipMaxX;
		
		try {
			parse();
			this.isdefined=true;
			
		} catch (Exception e) {
			e.printStackTrace();
			this.isdefined=false;
			return;
		}
		super.reCalculate(clipMinX,clipMaxX);
	}
	*/
	
	public boolean setExpression(String expr) {
		this.expr=expr;
		this.path=null;
		try {
			parse();
			this.isdefined=true;
			
		} catch (Exception e) {
			e.printStackTrace();
			this.isdefined=false;
			this.errInfo=e.getMessage();
			return false;
		}
		return true;
	}

	
	public void parse() throws FunctionParseErrorException{
	    if (expr.trim()=="")throw new FunctionParseErrorException("The Expression can not be empty");
	    String newExpr="";
    	StringReader sr = new StringReader(expr); 
    	BufferedReader br = new BufferedReader(sr); 
    	String nextLine = "";
    	//Store all statements in String List
    	ArrayList<String> lines=new ArrayList<String>();
    	try {
			while ((nextLine = br.readLine()) != null){ 
				String[] str=nextLine.split(";") ;
				for (String string: str){
					string=string.trim();
					if (string.length()>0)	{
						lines.add(string);
					}
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
			throw new FunctionParseErrorException("Can't parse Function:"+e.getMessage());
		} 
     	this.expr=newExpr;
    	/*
    	 * prepareParser
    	 */
    	funcList=new ArrayList<Function2D>();
    	try {
    		for (String s:lines){
    			Function2D func=Function2D.parseWithInterval(s,minX,maxX);
    			funcList.add(func);
				newExpr=newExpr+ " ; "+s;
    		}
		} catch (FunctionParseErrorException e) {  
			int i=funcList.size()+1;
			funcList.clear();
			//e.printStackTrace();
			throw new FunctionParseErrorException("Error in Function Definition:"+i+": "+e.getMessage());
		}  		
		if (!checkDomain())throw new FunctionParseErrorException("Domain can not be Overlapping");
		this.isdefined=true;
		this.expr=newExpr.substring(2,newExpr.length());
	}
    	   
	private boolean checkDomain() {
		Collections.sort(funcList);
		Function2D f1=funcList.get(0);
		for (int i=1;i<funcList.size();i++){
			Function2D f2=funcList.get(i);
			if ((f1.maxX>f2.minX)||(((f1.maxX)==(f2.minX))&&(f1.rightClosed && f2.leftClosed))){
				System.out.println("Domain Overlapping in function no."+i+"and"+(i+1));
				return false;
			}
			f1=f2;
		}
		return true;
	}

	
	/**
	 * @return the functions
	 */
	public ArrayList<Function2D> getFunctions() {
		return funcList;
	}
	/**
	 * @param functions the functions to set
	 */
	public void setFunctions(ArrayList<Function2D> functions) {
		this.funcList = functions;
	}
	
	@Override
	public double getY(double x){
		for(Function2D func:funcList){
			if (func.isInDomain(x)) return func.getY(x);
		}
		return Double.NaN;
	}
	
	
	@Override
	public boolean isInDomain(double x){
		for(Function2D func:funcList){
			if (func.isInDomain(x)) return true;
		}
		return false;
	}
	
	@Override
	public boolean contains(double x, double y) {
		if (!this.isdefined) return false;
		for(Function2D func:funcList){
			if (func.contains(x,y)) return true;
		}
		return false;
	}

	@Override
	public double distance(double x, double y) {
		if (!this.isdefined) return Double.POSITIVE_INFINITY;
		double dist=Double.POSITIVE_INFINITY;
		for(Function2D func:funcList){
			Double d=func.distance(x, y);
			if (dist<d) dist=d;
		}
		return dist;

	}
	
	@Override
    public Path2D createPath(Box2D clip,double numSegmentsPerX , boolean reCreate,  AffineTransform at){
		if (!isDefined())
			return null;
		if (path != null && !reCreate)
			return path;
		path = new Path2D.Double();
		this.shapes.clear();
		for (Function2D f : funcList) {
			Path2D p = f.createPath(clip, numSegmentsPerX, reCreate, at);
			if (p != null) {
				path.append(p, this.isContinuousAt(f.minX));
				if (!this.isContinuousAt(f.minX)) {
					f.evaluator.setVarValue(variable, f.minX);
					double y = f.evaluator.getValue();
					if (!Double.isNaN(y)) {
						this.shapes.add(new Dot2D(f.minX, y, f.leftClosed));
					}
				}
				if (!this.isContinuousAt(f.maxX)) {
					f.evaluator.setVarValue(variable, f.maxX);
					double y = f.evaluator.getValue();
					if (!Double.isNaN(y)) {
						this.shapes.add(new Dot2D(f.maxX, y, f.rightClosed));
					}
				}
				this.shapes.trimToSize();
			}

		}
		
		return path;
		
	}

	
		
}
