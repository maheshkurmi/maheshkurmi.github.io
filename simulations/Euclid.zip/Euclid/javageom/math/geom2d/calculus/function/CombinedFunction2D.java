package math.geom2d.calculus.function;

public class CombinedFunction2D extends Function2D {

	protected Function2D f;
	protected Function2D g;

	protected FunctionCombineType combType;

	/**
	 * Creates a new function by combination of two functions
	 * 
	 * @param f
	 * @param combType
	 *            Type of combination {@link Function2D.FunctionCombineType}
	 */
	public CombinedFunction2D(Function2D f, Function2D g,
			FunctionCombineType combType) {
		super();
		if (!f.isdefined || !g.isdefined) {
			this.expr = "";
			this.isdefined = false;
			this.isValidExpr = false;
			return;
		}

		this.combType = combType;
		this.f = f;
		this.g = g;

		// take domain as intersection of two domains
		this.minX = Math.max(f.minX, g.minX);
		this.maxX = Math.min(f.maxX, g.maxX);

		leftClosed = (f.minX == g.minX) && f.leftClosed && g.leftClosed;
		rightClosed = (f.maxX == g.maxX) && f.rightClosed && g.rightClosed;

		this.isdefined = true;
		isValidExpr = false;
		expr = createExpression();
	}

	//@Override
	public void reCalculate(double clipMinX,double clipMaxX){
		if (!f.isdefined || !g.isdefined) {
			this.expr = "";
			this.isdefined = false;
			this.isValidExpr = false;
			return;
		}
		// take domain as intersection of two domains
		this.minX = Math.max(f.minX, g.minX);
		this.maxX = Math.min(f.maxX, g.maxX);

		leftClosed = (f.minX == g.minX) && f.leftClosed && g.leftClosed;
		rightClosed = (f.maxX == g.maxX) && f.rightClosed && g.rightClosed;

		this.isdefined = true;
		isValidExpr = false;
		expr = createExpression();

		
	}
	
		
	private String createExpression() {
		if (!(f.expr == "") || !(g.expr == ""))
			return "";

		String s1 = f.getExpression();
		String s2 = g.getExpression();
		String s;
		if (combType == FunctionCombineType.ADD) {
			s = s1 + " + " + s2;
		} else if (combType == FunctionCombineType.SUBTRACT) {
			s = s1 + " - ( " + s2 + ")";
		} else if (combType == FunctionCombineType.MULTIPLY) {
			s = "(" + s1 + ") * (" + s2 + ")";
		} else if (combType == FunctionCombineType.DIVIDE) {
			s = "(" + s1 + ") / (" + s2 + ")";
		} else if (combType == FunctionCombineType.COMPOSITE) {
			s = s1.replace("x", "(" + s2 + ")");
		} else if (combType == FunctionCombineType.MIN) {
			s = "min(" + s1 + "," + s2 + ")";
		} else if (combType == FunctionCombineType.MAX) {
			s = "max(" + s1 + "," + s2 + ")";
		} else {
			s = "";
		}
		return s;
	}

	@Override()
	public double getY(double x) {
		if (!this.isdefined)
			return Double.NaN;
		if (!isInDomain(x))
			return Double.NaN;

		double y1 = f.getY(x);
		double y2 = g.getY(x);
		if (Double.isNaN(y1) || Double.isNaN(y2))
			return Double.NaN;

		if (combType == FunctionCombineType.ADD) {
			return y1 + y2;
		} else if (combType == FunctionCombineType.SUBTRACT) {
			return y1 - y2;
		} else if (combType == FunctionCombineType.MULTIPLY) {
			return y1 * y2;
		} else if (combType == FunctionCombineType.DIVIDE) {
			return y1 / y2;
		} else if (combType == FunctionCombineType.COMPOSITE) {
			return f.getY(y2);
		}else if (combType == FunctionCombineType.MIN) {
			return Math.min(y1 , y2);
		} else if (combType == FunctionCombineType.MAX) {
			return Math.max(y1 , y2);
		} else {
			return Double.NaN;
		}

	}

	@Override
	public CombinedFunction2D subCurve(double t0, double t1) {
		if (t0 < this.minX || t1 > this.maxX)
			return null;
		Function2D f = this.f.subCurve(t0, t1);
		Function2D g = this.g.subCurve(t0, t1);

		return new CombinedFunction2D(f, g, this.combType);
	}

}
