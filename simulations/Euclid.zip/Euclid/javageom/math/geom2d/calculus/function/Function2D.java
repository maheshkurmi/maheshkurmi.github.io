package math.geom2d.calculus.function;

import static java.lang.Math.abs;
import gui.EuclideGui;

import java.awt.geom.AffineTransform;
import java.awt.geom.GeneralPath;
import java.awt.geom.Path2D;
import java.util.ArrayList;
import java.util.Collection;

import org.apache.log4j.Logger;
import org.lsmp.djep.djep.DJep;
import org.lsmp.djep.rpe.RpCommandList;
import org.lsmp.djep.rpe.RpEval;
import org.nfunk.jep.Node;

import util.CurveUtils;
import dynamic.DynamicMeasure2D;
import dynamic.DynamicShape2D;
import math.geom2d.AffineTransform2D;
import math.geom2d.Box2D;
import math.geom2d.GeometricObject2D;
import math.geom2d.JEPFunction;
import math.geom2d.Point2D;
import math.geom2d.Shape2D;
import math.geom2d.Vector2D;
import math.geom2d.calculus.CalculusUtils;
import math.geom2d.calculus.Plottable2D;
import math.geom2d.conic.Circle2D;
import math.geom2d.curve.AbstractSmoothCurve2D;
import math.geom2d.curve.CurveArray2D;
import math.geom2d.curve.CurveSet2D;
import math.geom2d.line.LinearShape2D;


/**
 * Class to represent 2D cartesian curve y=f(x)
 * @author mahesh
 *
 */
public class Function2D extends AbstractSmoothCurve2D implements Plottable2D, Comparable<Function2D>{
	/**List of shapes to store more info for curve eg Asymptotes, void points , singularities local min/max etc*/
	protected ArrayList<Shape2D>shapes=new ArrayList<Shape2D>();
	/** Apache log4j Logger */
	private static Logger logger = Logger.getLogger("Function2D");

	protected Path2D path=null;

	/**domain of function */
	public double minX=-10;
	public double maxX=+10;

	/**clipped range of function */
	protected double minY=-10;
	protected double maxY=+10;

	/**parser for function*/
	protected DJep evaluator;

	/**independent variable for this cartesian function*/
	public final String variable = "x"	;
	
	/**expression for function 
	 (if expr="" means either function is not parsable or its value is defined from some parent function) 	*/
	protected String expr;
	
	/**Flag to check if function is defined or not*/
	protected boolean isdefined=false;
	
	/**stores error why function is  not defined*/
	protected String errInfo="";
	
	/** Domain Left right Intervals open or closed */
	public boolean leftClosed=false,rightClosed=false; 
	
	/**Flag to check if expression of function is valid*/
	protected boolean isValidExpr=false;

    public final static double PRECISION=1E-9;
    
    public Function2D(){
		this.isdefined=false;
		this.expr="";
		path=null;
		shapes=new ArrayList<Shape2D>();
		evaluator=new DJep();
		evaluator.addVariable(variable, 0);
	}
	
	/**
	 * Constructor for cartesian function y=f(x)
	 * @param s Expression as function of x
	 * @param minX 
	 * @param maxX
	 */
	public Function2D(String s, double minX,double maxX){
		this();
		if (s=="") return;
		this.setExpression(s);
		this.minX=minX;
		this.maxX=maxX;
		setDomain(this.minX, this.maxX);
	}
	
	/*
	public void reCalculate(double clipMinX,double clipMaxX){
		path=null;
		this.shapes.clear();
	}
	*/
	
	public boolean isInDomain(double x){
		if (x==minX && !leftClosed)return false;
		if (x==maxX && !rightClosed)return false;
		return !(x<minX || x>maxX);
	}

	/**
	 * @return minimum allowed input (x)
	 */
	public double getMinX() {
		return minX;
	}

	/**
	 * @return the maximum allowed input (x)
	 */
	public double getMaxX() {
		return maxX;
	}

	/**
	 * @return the shapes
	 */
	public ArrayList<Shape2D> getShapes() {
		return shapes;
	}


	/**
	 * returns true if function is defined i.e. is nonEmpty having valid domain and range
	 * @return
	 */
	public boolean isDefined(){
		if (!isdefined)return false ;

		if ((errInfo==null)||(errInfo.isEmpty()))
			return true;
		else 
			return false;
	}
	
	/**
	 * returns true if expression of f(x) is parsable
	 * @return
	 */
	public boolean isValidExpr() {
		return isValidExpr;
	}

	/**
	 * returns error if any in defining function it includes parser error and domain error
	 * @return
	 */
	public String getErrInfo(){
		return errInfo;
	}
	
	@Override
	public String toString(){
		String str;
		str=expr+"   "+(leftClosed?"[":"(")+CurveUtils.formatValue(minX,true)+","+CurveUtils.formatValue(maxX,true)+(rightClosed?"]":")");
		return str;
	}
	
	/**
	 * returns value of function of given input s
	 * @param x
	 * @return Double.NaN if x is outside defined domain for function else returns value of function at x
	 */
	public double getY(double x){
		if (!this.isdefined) return Double.NaN;
		if (!isInDomain(x)) return Double.NaN;
		evaluator.setVarValue(variable, x);
		return evaluator.getValue();
		
	}
	
	/**
	 * returns true if f(x) is continous at x
	 * @param x
	 * @return true if f(x) is continuous at x
	 */
	public boolean isContinuousAt(double x){
		double y=getY(x);
		if (Double.isNaN(y))return false;
		double y1=getY(x+ACCURACY);
		if (Double.isNaN(y1))return false;
		double y2=getY(x-ACCURACY);
		if (Double.isNaN(y2))return false;

		if(Math.abs(y1-y)<ACCURACY*100 && Math.abs(y2-y)<ACCURACY*100)return true;
		return false;
	}
	
	/**
	 * returns true if f(x) is Differentiable at x
	 * @param x
	 * @return true if f(x) is Differentiable at x
	 */
	public boolean isDifferentiableAt(double x){
		
		double y=getY(x);
		if (Double.isNaN(y))return false;
		double y1=getY(x+ACCURACY);
		if (Double.isNaN(y1))return false;
		double y2=getY(x-ACCURACY);
		if (Double.isNaN(y2))return false;
		
		//check for continuity
		
		if(Math.abs(y1-y)>ACCURACY*1000 || Math.abs(y2-y)>ACCURACY*1000)return false;

		//now check for differentiability
		double RHD=(y1-y)/ACCURACY;
		double LHD=(y-y2)/ACCURACY;
		double dD=Math.abs(RHD-LHD);
		double maxSlope= Math.max(Math.abs(RHD),Math.abs(LHD));
		if(maxSlope<ACCURACY*100000)maxSlope=ACCURACY*100000;
		//if difference of slopes exceeds 1% of max of either slopes , we assume it to be non diff
		if (dD>maxSlope/100.0)return false;
		return true;

	}
	@Override
	public Vector2D tangent(double x) {
		if (!this.isdefined) return null;
		if (!isInDomain(x)) return null;
		double m=getDerivative(x);
		if (m==Double.NaN) return null;
		return new Vector2D(1,m);
	}

	@Override
	public Function2D reverse() {
		return this;
	}

	@Override
	public Function2D subCurve(double t0, double t1) {
		if (!this.isdefined) return null;
		if (t0< this.minX || t1>this.maxX) return null;
		return new Function2D(this.expr, minX,maxX);
	}

	@Override
	public CurveSet2D<? extends Function2D> clip(Box2D box) {
		if (!this.isdefined) return null;
		Function2D f=new Function2D(this.expr, box.getMinX(),box.getMaxX());
		if (f.isdefined==false)return null;
		CurveArray2D<Function2D> set=new CurveArray2D<Function2D>();
		set.add(f);
		return set;
	}

	@Override
	public Function2D transform(AffineTransform2D trans) {
		//if (!this.isdefined) return null;
		return this;
	}

	@Override
	public boolean isClosed() {
		return false;
	}

	@Override
	public double curvature(double x) {
		if (!this.isdefined) return Double.NaN;
		if (!isInDomain(x))return Double.NaN;
		double y1=this.getDerivative(x);
		double y2=this.getDoubleDerivative(x);
		if(Double.isNaN(y1) || Double.isNaN(y2))return Double.NaN;
		
		if (Math.abs(y2)<Shape2D.ACCURACY)return 0;
		return (y2/(Math.pow(Math.hypot(1, y1),3)));
	}

	@Override
	public Path2D appendPath(Path2D path) {
		if (!this.isdefined) return path;
		path.lineTo(this.minX, this.getY(this.minX));
        path.append(this.asGeneralPath(),false);
        return path;
	}

	@Override
	public double t0() {
		return minX;
	}

	@Override
	public double getT0() {
		return t0();
	}

	@Override
	public double t1() {
		return maxX;
	}

	@Override
	public double getT1() {
		return t1();
	}

	@Override
	public Point2D point(double t) {
		if (!this.isdefined) return null;

		if (t<minX) t=minX;
		if (t>maxX) t=maxX;
		return new Point2D(t,getY(t));//.transform(AT);
	}

	@Override
	public double position(Point2D point) {
		if (!this.isdefined) return Double.NaN;

		if (contains(point))return point.x;
		return Double.NaN;
	}

	@Override
	public double project(Point2D point) {
		if (!this.isdefined) return Double.NaN;

		double x;
		if (point.x<=minX) x=minX;
		if (point.x>=minX) x=maxX;
		x=point.x;
		return x;
	}

	public Point2D projectPoint(Point2D P)
	{
		double varmin, varmax, dvar;
		varmin=this.minX;
		varmax=this.maxX;
		dvar = (varmax - varmin) / 1000;
		double[] X=new double[1];
		X[0] = varmin+dvar;
		double x = 0, y = 0, x0 = 0, y0 = 0, dmin = 0;
		boolean started = false;
		while (true)
		{
			try
			{
				double x1 = X[0];
				double y1 = getY(x1);
				if ( !started)
				{
					dmin = Math.sqrt((P.getX() - x1) * (P.getX() - x1)
						+ (P.getY() - y1) * (P.getY() - y1));
					x0 = x = x1;
					y0 = y = y1;
					started = true;
				}
				else
				{
					double h = (x1 - x0) * (x1 - x0) + (y1 - y0) * (y1 - y0);
					double g = (P.getX() - x0) * (x1 - x0) + (P.getY() - y0)
						* (y1 - y0);
					if (g < 0) g = 0;
					if (g > h) g = h;
					double x2 = x0 + g / h * (x1 - x0), y2 = y0 + g / h
						* (y1 - y0);
					double d = Math.sqrt((P.getX() - x2) * (P.getX() - x2)
						+ (P.getY() - y2) * (P.getY() - y2));
					if (d < dmin)
					{
						dmin = d;
						x = x2;
						y = y2;
					}
					x0 = x1;
					y0 = y1;
				}
			}
			catch (Exception e)
			{
				System.out.print(e.toString());
			}
			if (X[0] >= varmax) break;
			X[0] = X[0] + dvar;
			if (X[0] > varmax) X[0] = varmax;
		}
		if (started)
		{
			return new Point2D(x, y);
		}
		return null;
	}
	
	@Override
	public Collection<Point2D> intersections(LinearShape2D line) {
		if (!this.isdefined) return new ArrayList<Point2D>();
		
		return this.asPolyline((int) (10*(this.maxX-this.minX))).intersections(line);
		// return null;
	}

	@Override
	public boolean contains(double x, double y) {
		if (!this.isdefined) return false;
		if (!isInDomain(x))return false;
		return Math.abs(getY(x)-y)<Shape2D.ACCURACY;
	}

	@Override
	public boolean contains(Point2D p) {
		return this.contains(p.x,p.y);
	}

	@Override
	public double distance(Point2D p) {
		return p.distance(new Point2D(p.x,getY(p.x)));
	}

	@Override
	public double distance(double x, double y) {
		if (!this.isdefined) return Double.POSITIVE_INFINITY;
			return distance(new Point2D(x,y));
	}

	@Override
	public boolean isBounded() {
		return true;
	}

	@Override
	public boolean isEmpty() {
		return isDefined();
	}

	@Override
	public Box2D boundingBox() {
		if (!this.isdefined) return null;
		return new Box2D(minX,maxX,minY,maxY);
	}

	@Override
	public boolean almostEquals(GeometricObject2D obj, double eps) {
		if (!(obj instanceof Function2D)) return false;
		Function2D f=(Function2D)obj;
		if ((this.getExpression().equalsIgnoreCase(f.getExpression())) && this.minX==f.minX && this.maxX==f.maxX)return true;
		return false;
	}

	@Override
	public Function2D clone() {
		if (!this.isdefined) return null;
		return new Function2D(this.expr, this.minX, this.maxX);
	}

	/**
	 * @return the expr
	 */
	public String getExpression() {
		return expr;
	}

	
	public static Function2D parseWithInterval(String expr, double minAllowedX, double maxAllowedX) throws FunctionParseErrorException {
		//function definition and interval definition are separated by comma
		String[] arr=expr.split(",");
		Function2D f=new Function2D();
		f.setMin(minAllowedX, false);
		f.setMax(maxAllowedX, false);
		
		boolean isvalid=false;
		if (arr.length==1){//there is no interval definition so default interval is used
			isvalid=f.setExpression(arr[0]);
		}else{
			if (isInterval(arr[arr.length-1])){
				//System.out.println(expr.substring(0, expr.lastIndexOf(",")));
				isvalid=f.setExpression(expr.substring(0, expr.lastIndexOf(",")));
				isvalid=isvalid & f.setInterval(arr[arr.length-1]);
			}else{
				isvalid=f.setExpression(expr);
			}
		}
		
		if (f.isdefined) {
			//f.isdefined=true;
			return f;
		}else{
			throw new FunctionParseErrorException(f.getErrInfo());
		}
	}
	
/**
 * sets expression for the function
 * @param expr
 * @return true if successfully parsed
 */
	public boolean setExpression(String expr) {
		this.expr=expr;
		isdefined=false;
		isValidExpr=false;
		errInfo="";

		this.path=null;
		if (EuclideGui.getCurrentGui()==null || EuclideGui.getCurrentGui().getCurrentDoc()==null) return false;
		
		EuclideGui.getCurrentGui().getCurrentDoc().updateParser(evaluator);
		evaluator.addVariable(variable, 0);
		
		try {
			
			expr=CalculusUtils.PreProcessExpression(expr);
			Node node = evaluator.parseExpression(expr);
			errInfo = evaluator.getErrorInfo();
			if (errInfo!=null)throw new Exception(errInfo);
			
			isValidExpr=true;
			isdefined=true;
			return true;
		} catch (Exception e) {
			errInfo=e.getMessage();
			isValidExpr=false;
			isdefined=false;
			logger.warn("couldn't parse "+expr+ "because"+ evaluator.getErrorInfo()+" & Exception thrrown is"+e.getMessage());
		}
		return true;
	}
	
	
	private static boolean isInterval(String expr){
		if (expr.contains("<")||expr.contains(">")||expr.contains("="))return true;
		return false;
	}
	
    private boolean setInterval(String expr){
    	expr=preProcessInterval(expr);
    	//leftClosed=false;
    	//rightClosed=false;
     	if (expr.length()<3){
     		errInfo="Error in interval";
    		return false;
    	}
    	
    	//get position of x
    	int i=expr.indexOf("x");
       	if (i==0){
    		try{
    			 parseRightInequality(expr.substring(1));
       		}catch (Exception e){
    			 //System.out.println(e.getMessage());
    			 errInfo=e.getMessage();
    			 return false;
    		}
    	
       	}else if (i==expr.length()-1){
       		try{
       			parseLeftIneqaulity(expr.substring(0,i));
     		}catch (Exception e){
    			System.out.println(e.getMessage());
    			errInfo=e.getMessage();
    			return false;
    		}
      	}else if ((0<i)&&(i<expr.length())){
    		if (expr.length()<5){
    			errInfo="Error in interval";
        		return false;
        	}
    	    try{
    	       	parseLeftIneqaulity(expr.substring(0,i));	
    	    	parseRightInequality(expr.substring(i+1));
    	    }catch (Exception e){
    	   	    System.out.println(e.getMessage());
    	   	    errInfo=e.getMessage();
    			return false;
    	    }
    	}else {
    		errInfo="error in Interval: expected variable x";
    		return false;
    	}
       	
       	if (minX>=maxX){
       		if ((minX==maxX) && leftClosed && rightClosed)return true;
       		errInfo="Minimum value must be less than maximum value for interval";
       		return false;
       	}
        return true;
    }
	
    private String preProcessInterval(String expr) {
    	expr=expr.toLowerCase();
    	expr=expr.trim();
    	if(expr.contains(">") && expr.contains("<"))return "";
    	if (expr.length()<3)return "";
    	return expr;
   }

	private void parseRightInequality(String  expr) throws FunctionParseErrorException {
		expr=expr.trim();
		try{
    		 if (expr.length()<2)throw new Exception();
    	
    		 if (expr.startsWith("<=")||expr.startsWith("=<")){
    			 expr=expr.substring(2);
    			 double max=EuclideGui.getCurrentGui().getCurrentDoc().evaluateExpression(expr);
    	    	 if(Double.isNaN(max))throw new FunctionParseErrorException("invalid right limit");
       			 setMax(max,true);
    		 }else if(expr.startsWith("<")){
    			 expr=expr.substring(1);
    			 double max=EuclideGui.getCurrentGui().getCurrentDoc().evaluateExpression(expr);
    	    	 if(Double.isNaN(max))throw new FunctionParseErrorException("invalid right limit");
    			 setMax(max,false);
    		 }else if(expr.startsWith(">=")||expr.startsWith("=>")){
    			 expr=expr.substring(2);
    			 double min=EuclideGui.getCurrentGui().getCurrentDoc().evaluateExpression(expr);
    	    	 if(Double.isNaN(min))throw new FunctionParseErrorException("invalid right limit");
    			 setMin(min,true);
    		 }else if(expr.startsWith(">")){
    			 expr=expr.substring(1);
    			 double min=EuclideGui.getCurrentGui().getCurrentDoc().evaluateExpression(expr);
    	    	 if(Double.isNaN(min))throw new FunctionParseErrorException("invalid right limit");
    			 setMin(min,false);
    		 }else if (expr.startsWith("=")){
    			 expr=expr.substring(1);
    			 double val=EuclideGui.getCurrentGui().getCurrentDoc().evaluateExpression(expr);
    	    	 if(Double.isNaN(val))throw new FunctionParseErrorException("invalid value in limit");
    			 setMin(val,true);
    			 setMax(val,true);
    		 }else{
    			 throw new Exception("Invalid Inequality"); 
    		 }
 		}catch (Exception e){
 			 throw new FunctionParseErrorException("Error in parsing Limits of Function: "+ e.getMessage());
		}
    }
    
    private void parseLeftIneqaulity(String  expr) throws FunctionParseErrorException {
    	try{
    		 expr=expr.trim();
    		 int i=expr.length();
    		 if (i<2)throw new Exception();
    	     if (expr.endsWith("<")){
    	    	 expr=expr.substring(0,i-1);
    	    	 double min=EuclideGui.getCurrentGui().getCurrentDoc().evaluateExpression(expr);
    	    	 if(Double.isNaN(min))throw new FunctionParseErrorException("invalid left limit");
    	    	 setMin(min,false);
    	     }else if (expr.endsWith("<=")||expr.endsWith("=<")){
    	    	 expr=expr.substring(0,i-2);
    	    	 double min=EuclideGui.getCurrentGui().getCurrentDoc().evaluateExpression(expr);
    	    	 if(Double.isNaN(min))throw new FunctionParseErrorException("invalid left limit");
     	    	 setMin(min,true);
    	     }else if (expr.endsWith(">")){
    	    	 expr=expr.substring(0,i-1);
    	    	 double max=EuclideGui.getCurrentGui().getCurrentDoc().evaluateExpression(expr);
    	    	 if(Double.isNaN(max))throw new FunctionParseErrorException("invalid left limit");
    	    	 setMax(max,false);
    	     }else if (expr.endsWith(">=")||expr.endsWith("=>")){
    	    	 expr=expr.substring(0,i-2);
    	    	 double max=EuclideGui.getCurrentGui().getCurrentDoc().evaluateExpression(expr);
    	    	 if(Double.isNaN(max))throw new FunctionParseErrorException("invalid left limit");
     	    	 setMax(max,true);
    	     }else if (expr.startsWith("=")){
       			 expr=expr.substring(1);
       			 double val=EuclideGui.getCurrentGui().getCurrentDoc().evaluateExpression(expr);
       	    	 if(Double.isNaN(val))throw new FunctionParseErrorException("invalid value in limit");
       			 setMin(val,true);
       			 setMax(val,true);
    	     }else{
    	    	throw new Exception("Invalid Inequality"); 
    	     } 
     	 }catch (Exception e){
			 //System.out.println(e.toString());
  			 throw new FunctionParseErrorException("Error in parsing Limits of Function: "+ e.getMessage());
		}
    }
    
    public void setMax(double d,boolean closed){
		// System.out.println(d+":lowerlimit");
		 maxX=d;
		 rightClosed=closed;
   }
   
   public void setMin(double d,boolean closed){
       minX=d;
       leftClosed=closed;
   }
   
   public String getInterval(){
   		return (leftClosed?" [ ":" ( ")+minX+", "+maxX+(rightClosed?" ]":" )");
   }
   

	/**
	 * Sets domain for this function tries to truncate range of x from ends if function is not defined for the range
	 * @param minX
	 * @param maxX
	 * @return returns true if domain is successfully set
	 */
	public boolean setDomain(double minX, double maxX) {
		if (!isValidExpr)return false;
		double dx = 0.02;
		double x = minX;
		
		evaluator.addVariable(variable, x);
		// find first point that is in viewable portion of xy-plane
		while (x <= maxX && Double.isNaN(evaluator.getValue())) {
			x = x + dx;
			evaluator.addVariable(variable, x);
		}
		this.minX = x;
		x = maxX;
		while (x >= minX && Double.isNaN(evaluator.getValue())) {
			x = x - dx;
			evaluator.addVariable(variable, x);
		}
		this.maxX = x;
		
		if ((this.maxX-this.minX)<Shape2D.ACCURACY){
			errInfo="Invalid Domain";
			isdefined=false;
			path=null;
			return false;
		}

		/*
		if (evaluator.getErrorInfo().isEmpty()){
			this.isdefined=true;
			
			return true;
		}
		*/
		errInfo="";
		this.isdefined=true;
		path=null;
		return true;

	}
	

	/**
     * Creates Path for function Shape
     * @param clip
     * @param numSegmentsPerX Number of segments (>1) f(x) should be converted for one unit change in x(=zoom*dpu)
     */
    public Path2D createPath(Box2D clip,double numSegmentsPerX, boolean reCreate, AffineTransform at ){
    	if (!isDefined())return null;
    	if(path!=null && !reCreate)return path;
    	path=new Path2D.Double();
       	if (numSegmentsPerX<1)numSegmentsPerX=1;
		double x2;
		double x1;
		//if (numSegmentsPerX<40) numSegmentsPerX=40;
		double dx=1.0/numSegmentsPerX;
		double maxY=clip.getMaxY();
		double minY=clip.getMinY();
		double minX=Math.max(this.getMinX(),clip.getMinX());
		double maxX=Math.min(this.getMaxX(),clip.getMaxX());
		
		this.minY=clip.getMinY();
		this.maxY=clip.getMaxY();
		double x0=at.getTranslateX();
		double y0=at.getTranslateY();
		double sx=at.getScaleX();
		double sy=at.getScaleY();
		
		if ((maxX-minX)<Shape2D.ACCURACY){
			//errInfo="No visible domain";
			//isdefined=false;
			return null;
		}
		//evaluator.addVariable( variable, minX );

		double x=minX;
		double y = getY(x);
		double oldy = y;

		while ( x < maxX ){
			// find first point that is in viewable portion of xy-plane
			while ( x<=maxX && (Double.isNaN(y=getY(x)) || y>maxY ||  y<minY) ){
				x=x+dx;
				//evaluator.addVariable( variable, x );
			}
			//find a slightly better place to moveto
			oldy = y;
			x1 = x - dx;
			x2 = x;
			for ( int l=0; l<20; l++ ){
				if ( Double.isNaN(getY( (x1 + x2)/2)) ){
					x1 = (x1 +x2)/2;
				} else {
					oldy = getY((x1+x2)/2);
					x2 = (x1 + x2)/2;
				}
			}
			path.moveTo( x0+sx*(float)x2, y0+sy*(float)(oldy) );
			path.lineTo( x0+sx*(float)x,y0+sy* (float)(y) );

			
			// keep going until off the screen or not in domain
			x=x+dx;
			while ( x<maxX && y<maxY && y>minY && !Double.isNaN(y=getY(x)) ){
				if (Math.atan(Math.abs(y-oldy)/dx)>1.54){
					//shapes.add(new LineSegment2D(x,oldy,x,y));
					//x=x+dx;
					//break;
				}
				path.lineTo(x0+ sx*x, y0+sy*y);
				oldy = y;
				x=x+dx;
				//evaluator.addVariable( variable, x );
			}
			
			// backup a little bit
			/*
			x1 = x - dx;
			x2 = x;
			for ( int l=0; l<20; l++ ){
				if ( Double.isNaN(getY((x1 + x2)/2)) ){
					x1 = (x1 +x2)/2;
				} else {
					oldy = getY((x1 + x2)/2);
					x2 = (x1 + x2)/2;
				}
			}
			
			path.moveTo( (float)x2, (float)(oldy) );
			*/
		}
		
		//create shapes associated with function
		/*
		if (!domainRedefined && this.isValidExpr) {
			this.shapes.clear();

			evaluator.setVarValue(variable, this.minX);
			y = evaluator.getValue();
			if (!Double.isNaN(y)) {
				this.shapes.add(new Dot2D(this.minX, y, leftClosed));
			}
			evaluator.setVarValue(variable, this.maxX);
			y = evaluator.getValue();
			if (!Double.isNaN(y)) {
				this.shapes.add(new Dot2D(this.maxX, y, rightClosed));
			}
			this.shapes.trimToSize();
		}
		*/
		//path.transform(at);
		return path;

	}

    /**
     * Returns a general path iterator.
     */
    public Path2D asGeneralPath() {
        return this.path;
    }
    
    
	/**
	 * This is a brute force method of calculating derivatives, using
	 * Newton's difference quotient (except without a limit)
	 * 
	 * The derivative of a function f and point x can be approximated by
	 * taking the slope of the secant from x to x+h, provided that h is sufficently
	 * small. However, if h is too small, then floating point errors may result.
	 * 
	 * This algorithm is an effective 100-point stencil in one dimension for
	 * calculating the derivative of any real function y=equation.
	 * @param xval
	 * @return
	 */

	public double getDerivative (double xval){
	   	if (!isDefined())return Double.NaN;
	   	if (!isInDomain(xval))return Double.NaN;
	   	
	 	if(!isDifferentiableAt(xval))return Double.NaN;
		
	   	double ddx = 0;
	
		//The suitable value for h is given at http://www.nrbook.com/a/bookcpdf/c5-7.pdf to be sqrt(eps) * x
		double x = xval;
		
		double h;
		if(x > 1 || x < -1)
			 h = Math.sqrt(Shape2D.ACCURACY) * x;
		else
			 h = Math.sqrt(Shape2D.ACCURACY);
		
		double answerx = getY(xval);	//Find f(x)
		
		for(int i = 1; i <= 5; i++) {
			double diff = (h * i);
			
			//h is positive
			xval = x + diff;
			double answer = getY(xval);
			ddx += ((answer - answerx) / diff);
			
			//h is negative
			xval = x - diff;
			answer = getY(xval);
			ddx += ((answerx - answer) / diff);
		}
	
		ddx = ddx / 10;
		return ddx;
	}
	
	/**
	 * returns double derivative of function for input x
	 * @param xval
	 * @return
	 */
	public double getDoubleDerivative (double xval){
	   	if (!isDefined())return Double.NaN;
	   	if (!isInDomain(xval))return Double.NaN;
		
		double ddx = 0;
	
		//The suitable value for h is given at http://www.nrbook.com/a/bookcpdf/c5-7.pdf to be sqrt(eps) * x
		double x = xval;
		
		double h;
		if(x > 1 || x < -1)
			 h = Math.sqrt(Shape2D.ACCURACY) * x;
		else
			 h = Math.sqrt(Shape2D.ACCURACY);
		
		double answerx = getDerivative(xval);	//Find f(x)
		
		for(int i = 1; i <= 5; i++) {
			double diff = (h * i);
			
			//h is positive
			xval = x + diff;
			double answer = getDerivative(xval);
			ddx += ((answer - answerx) / diff);
			
			//h is negative
			xval = x - diff;
			answer = getDerivative(xval);
			ddx += ((answerx - answer) / diff);
		}
	
		ddx = ddx / 10;
		return ddx;
	}
	
	/**
	 * Uses Newton's method to find the root of the equation. Accurate enough for these purposes.
	 * @param f
	 * @param guess
	 * @param range
	 * @param shifted
	 * @return
	 */

	public static double getRoot_Newton(Function2D f, double guess, double range, boolean shifted){
	  	if (!f.isDefined())return Double.NaN;
		
		//System.out.println(f.getExpression() + ", guess: "+guess);
		//Newton's method becomes very inaccurate if the root is too close to zero. Therefore we just whift everything over a few units.
		if((guess > -0.2 || guess < 0.2) && shifted != true) {
			//dump(equation.replace(/x/g, "(x+5)"));
			double answer = getRoot_Newton(new TransformedFunction2D(f,FunctionTransformType.TRANSLATE_X,-5), (guess - 5), range, true);
			if(Double.isNaN(answer))
				return answer + 5;
			else return answer;
		}
		
		if(range<0.2) range = 5;
		
		double center = guess;
		double prev = guess;
		int j = 0;
		while (prev > center - range && prev < center + range && j < 100) {
			double xval = prev;
			double answer = f.getY(xval);
			
			if (answer > -PRECISION && answer < PRECISION) {
				return prev;
			}
			
			double derivative = f.getDerivative(xval);
			if (Double.isNaN(derivative)) 
				break;
			
			prev = prev - answer / derivative;
			j++;
		}
		//System.out.println("false: center at "+center+" but guess at "+prev);
		
		return Double.NaN;
	}

	public static double getRoot_Bisection(Function2D f, double guess, double range, boolean shifted){
	    int i = 0;
	    double x = guess;
	    double b=guess+range;
	    double a=guess-range;
	    double dx = b - a;

	   int  maxIteration=100;
	    while (i <  maxIteration)
	    {
	      if (Math.abs(dx) < PRECISION)
	      {
	        System.out.println("Iteration number: " + i);
	        System.out.println("Root obtained: " + x);
	        System.out.println("Estimated error: " + dx);
	        return x;
	      }
	      x = (a + b) / 2;
	      // is same sign for f(a) and f(x)
	      if(f.getY(a) * f.getY(x) < 0) 
	      {
	        // not same sign, move b to x
	        b = x;
	        dx = b - a;
	      }
	      else
	      {
	        // same sign, move a to x
	        a = x;
	        dx = b - a;
	      }
	      i++;
	    }
	    return Double.NaN;
	}
	
	/**
	 * Computes intersection of 2 functions in neighbourhood of guess value (this searches for gues+range and guess-range)
	 * @param f
	 * @param g
	 * @param guess
	 * @param range
	 * @return
	 */
	public static double getIntersection(Function2D f, Function2D g,double guess, double range){
	   	if (!f.isDefined()|| !g.isDefined())return Double.NaN;
		
		Function2D fminusg=new CombinedFunction2D(f,g,FunctionCombineType.SUBTRACT);
		if (!fminusg.isdefined)return Double.NaN;
		return getRoot_Bisection(fminusg,guess,range,true);
		
	}


	
	static double loopcounter=0;
	
	
	//Terribly Inaccurate. Ah well.
	public static double getCriticalPoint(Function2D f, double start,double end ){
		loopcounter++;
		double precision=PRECISION*1000;
		if(Math.abs(end - start) <= precision) {
			loopcounter = 0;
			return (end + start) / 2;
		}
		if(loopcounter > 50) {
			loopcounter = 0;
			return Double.NaN;
		}

		double interval = (end-start) / 10;
		double xval = start - interval;
		double startanswer;
		double prevanswer = startanswer = f.getY(xval);
		for(double x = start; x <= end; x += interval) {
			double answer = f.getY(x);
			if((prevanswer > startanswer && answer < prevanswer) || (prevanswer < startanswer && answer > prevanswer)) {
				return getCriticalPoint(f, x - 2*interval, x);
			}
			prevanswer = answer;
		}
		loopcounter = 0;
		return Double.NaN;
	}
	
	public Circle2D getOscullatingCitcle(Point2D point) {
    	// project point on curve
		double x=point.x;
		double y=getY(x);
		if (Double.isNaN(y)) return null;
		Point2D foot = new Point2D(x,y);
			// extract curvature
		double r = curvature(x);
		if (abs(r) < PRECISION || abs(r)>1/ PRECISION )
			return null;
		
		r = -1 / r;
		Vector2D v = tangent(x);
		v=v.normalize();
		v = new Vector2D(r * v.y(), -r * v.x());
		Point2D centre = foot.plus(v);
		//return new Circle2D(centre, r);
		
		return new Circle2D(centre,	Math.abs(r));
	} 
	
	
	@Override
	public int compareTo(Function2D f) {
		 if (minX<f.minX) return -1;
	     else if (minX>f.minX) return 1;
	     else return 0;
	}
	
	@Override
    public java.awt.Shape asAwtShape(){
    	return path;
    }
    
	 /**
     * The different types of shapes.
     */
    public enum FunctionTransformType {
        /** TransLate function along x*/
        TRANSLATE_X,
        /** TransLate function along y*/
        TRANSLATE_Y,
        /** Scale function along x*/
        SCALE_X,
        /** Scale function along x*/
        SCALE_Y,
     }
    
    /**
     * The different types of Function Combination mode.
     */
    public enum FunctionCombineType {
        /** Add two function f+g */
        ADD,
        /** subtract one function from other f-g */
        SUBTRACT,
        /** Multiply two functions f*g */
        MULTIPLY,
        /** Divide two functions f/g */
        DIVIDE,
        /** Composite of two functions fog */
        COMPOSITE,
        /** minimum of two functions */
        MIN,
        /** maximum of two functions */
        MAX
     }

    
 
}
