package math.geom2d.calculus.function;

import java.awt.geom.AffineTransform;
import java.awt.geom.GeneralPath;
import java.awt.geom.Path2D;

import math.geom2d.Box2D;
import math.geom2d.Shape2D;

public class IntegrationFunction2D extends Function2D{

	protected Function2D baseFunction;

	protected double lowerLimit, upperLimit;
	
	/**constant term*/
	private double c=0;
	
	private double clipXmin=0;
	/**
	 * Creates function as integration of given function from limit a to x
	 * @param f
	 */
	public IntegrationFunction2D(Function2D f, double lowerLimit, double upperLimit){
		super();
		path=null;
		isValidExpr = false;
		this.expr="";
		this.baseFunction=f;

		//set limits		
		this.minX=Math.max(lowerLimit,baseFunction.minX);
		this.maxX=Math.min(upperLimit,baseFunction.maxX);
		setDomain(lowerLimit,upperLimit);
	}
	
	@Override
	public boolean setDomain(double lowerLimit, double upperLimit){
		path=null;
		this.shapes.clear();
		this.c=0;
		this.lowerLimit=Math.min(lowerLimit,upperLimit);
		this.upperLimit=Math.max(lowerLimit,upperLimit);
		this.minX=lowerLimit;
		this.maxX=upperLimit;
		
		if (this.minX<baseFunction.minX)this.minX=baseFunction.minX;
		if (this.maxX>baseFunction.maxX )this.maxX=baseFunction.maxX;
	
		if (this.lowerLimit>=this.upperLimit || this.minX>=this.maxX || !baseFunction.isdefined){
			isdefined=false;
			return false;
		}
		isdefined=true;
		errInfo="";
		calculateConstant();
		return true;
	}
	
	/*
	@Override
	public void reCalculate(double clipMinX,double clipMaxX){
	
		if (!baseFunction.isdefined){
			isValidExpr = false;
			expr="";
			isdefined=false;
			return;
		}
		this.isdefined=true;
		if (lowerLimit<baseFunction.minX || lowerLimit>baseFunction.maxX)this.isdefined=false;
		if (upperLimit<baseFunction.minX || upperLimit>baseFunction.maxX)this.isdefined=false;
		
		if (!this.isdefined)return;
		this.lowerLimit=Math.min(lowerLimit,upperLimit);
		this.upperLimit=Math.max(lowerLimit,upperLimit);
		
		this.minX=this.lowerLimit;
		this.maxX=this.upperLimit;
		this.isdefined=baseFunction.isdefined;
		this.setExpression("");
		
	
		super.reCalculate(clipMinX,clipMaxX);
	}
	*/
//9752416064
	/**
	 * Evaluates constant term of integration
	 */
	private void calculateConstant(){
		this.c= 0;
		
		if (baseFunction instanceof PieceWiseFunction2D
				|| baseFunction.evaluator == null) {
			if (this.minX < clipXmin) {
				double dt = 0.01;
				double y = 0;
				for (double t = minX; t < clipXmin; t += dt) {
					// baseFunction.evaluator.setVarValue(variable, t);
					y += baseFunction.getY(t) * dt;
					if (Double.isNaN(y) || Double.isInfinite(y)) {
						return;
					}
				}
				c = y;
			}
		} else {
			if (this.lowerLimit < clipXmin) {
				double dt = 0.01;
				double y = 0;
				for (double t = lowerLimit; t < clipXmin; t += dt) {
					 baseFunction.evaluator.setVarValue(variable, t);
					y += baseFunction.evaluator.getValue()*dt;//getY(t) * dt;
					if (Double.isNaN(y) || Double.isInfinite(y)) {
						return;
					}
				}
				c = y;
			}
		}
		
	}
	
	@Override()
	public double getY(double x){
	//if (x<this.minX || x>this.maxX)return Double.NaN;
		double dt=0.01;
		double y=0;
		for (double t=minX+dt;t<=x;t+=dt){
			y+=(baseFunction.getY(t)*dt);
			if (Double.isNaN(y) || Double.isInfinite(y))return Double.NaN;
		}
		//add constant term
		return y+c;
	}
	

	public double getY(double x, double y, double dx){
		double h=(baseFunction.getY(x)+baseFunction.getY(x+dx))/2;
		y+=h*dx;
		if (Double.isNaN(y) || Double.isInfinite(y))return Double.NaN;
		
		return y;
		/*
		double dt=dx/5;

		for (double t=x;t<=x+dx-dt;t+=dt){
			y+=(baseFunction.getY(t)*dt);
		}
		
		if (Double.isNaN(y) || Double.isInfinite(y))return Double.NaN;
		
		*/
	}
	
	public Function2D getBaseFunction() {
		return baseFunction;
	}

	public double getDerivative (double x){
	   	if (!isDefined())return Double.NaN;
	   	return this.baseFunction.getY(x);
	}
	
	public double getDoubleDerivative (double x){
	   	if (!isDefined())return Double.NaN;
	   	return this.baseFunction.getDerivative(x);
	}
	
	
	@Override
	public IntegrationFunction2D subCurve(double t0, double t1) {
		if (t0< this.minX || t1>this.maxX) return null;
		Function2D f=this.baseFunction.subCurve(t0, t1);
		return new IntegrationFunction2D(f,t0,t1);
	}
	
	  /**
     * Creates Path for function Shape
     * @param clip
     * @param numSegmentsPerX Number of segments (>1) f(x) should be converted for one unit change in x(=zoom*dpu)
     */
	@Override
    public Path2D createPath(Box2D clip,double numSegmentsPerX ,boolean reCreate, AffineTransform at ){
    	if (!isDefined())return null;
    	if(path!=null && !reCreate)return path;
    	clipXmin=clip.getMinX();

    	calculateConstant();
 		path = new Path2D.Double();
 	   	if (numSegmentsPerX<1)numSegmentsPerX=1;

		double x2;
		double x1;
		//if (numSegmentsPerX<40) numSegmentsPerX=40;
		double dx=1/numSegmentsPerX;
			double maxY=clip.getMaxY();
		double minY=clip.getMinY();
		double minX=Math.max(this.getMinX(),clip.getMinX());
		double maxX=Math.min(this.getMaxX(),clip.getMaxX());
		
		this.minY=clip.getMinY();
		this.maxY=clip.getMaxY();
		
		
		if ((maxX-minX)<Shape2D.ACCURACY){
			errInfo="No visible domain";
			isdefined=false;
			return path;
		}
		//evaluator.addVariable( variable, minX );

		double x=minX+dx;
		double y = c;
		double oldy = y;

        //loop ends if integration becomes not defined or infinity
		while ( x < maxX && !(Double.isNaN(y)||Double.isInfinite(y))){
			// find first point that is in viewable portion of xy-plane
			while ( x<=maxX && (Double.isNaN(y=getY(x,y,dx)) || y>maxY ||  y<minY) ){
				x=x+dx;
				//evaluator.addVariable( variable, x );
			}
			//find a slightly better place to moveto
			oldy = y;
			x1 = x - dx;
			x2 = x;
			for ( int l=0; l<20; l++ ){
			if ( Double.isNaN(getY( (x1 + x2)/2,y,dx)) ){
					x1 = (x1 +x2)/2;
				} else {
					oldy = getY((x1+x2)/2,y,dx);
					x2 = (x1 + x2)/2;
				}
			}
			path.moveTo( x2, oldy );
			path.lineTo( x, y );

			// keep going until off the screen or not in domain
			x=x+dx;
			while ( x<maxX && y<maxY && y>minY && !Double.isNaN(y=getY(x,y,dx)) ){
				if (Math.atan(Math.abs(y-oldy)/dx)>1.545){
					//shapes.add(new LineSegment2D(x,oldy,x,y));
					//x=x+dx;
					//break;
				}
				path.lineTo( x, y);
				oldy = y;
				x=x+dx;
				//evaluator.addVariable( variable, x );
			}
			
			// backup a little bit
			x1 = x - dx;
			x2 = x;
			for ( int l=0; l<20; l++ ){
				if ( Double.isNaN(getY((x1 + x2)/2,y,dx)) ){
					x1 = (x1 +x2)/2;
				} else {
					oldy = getY((x1 + x2)/2,y,dx);
					x2 = (x1 + x2)/2;
				}
			}
			
			path.moveTo( x2, oldy );
		}
		path.transform(at);
		return path;

	}
	
}
