package math.geom2d.calculus.function;
@SuppressWarnings("serial")
class FunctionParseErrorException extends Exception{

	public FunctionParseErrorException(String parseErrorMgs) {
		super(parseErrorMgs);
	}
	 
 }
