package math.geom2d.calculus.function;

public class TransformedFunction2D extends Function2D{

	protected Function2D baseFunction;
	protected FunctionTransformType transType;
	protected double transformValue;
/**
 * Creates a new function after transformation
 * @param f
 * @param transType Type of transformation {@link Function2D.FunctionTransformType}
 * @param transformValue amount by which function is transformed
 */
	public TransformedFunction2D(Function2D f, FunctionTransformType transType, double transformValue){
		super();
		this.transType=transType;
		this.transformValue=transformValue;
		
		if (!f.isdefined || Math.abs(transformValue)<ACCURACY ){
			isValidExpr=false;
			isdefined=false;
			return;
		}
		if (transType == FunctionTransformType.TRANSLATE_X) {
			this.minX=f.minX+transformValue;
			this.maxX=f.maxX+transformValue;
		}else if(transType==FunctionTransformType.SCALE_X){
			this.minX=f.minX*transformValue;
			this.maxX=f.maxX*transformValue;
		} else {
			this.minX=f.minX;
			this.maxX=f.maxX;
		}
		leftClosed=f.leftClosed;
		rightClosed=f.rightClosed;
		this.baseFunction=f;
		this.isdefined=f.isdefined;
		isValidExpr=false;
		expr=createExpression();
	}
	
	/*
	@Override
	public void reCalculate(double clipMinX,double clipMaxX){
		if (!baseFunction.isdefined || Math.abs(transformValue)<ACCURACY ){
			isValidExpr=false;
			isdefined=false;
			return;
		}

		if (transType == FunctionTransformType.TRANSLATE_X) {
			this.minX=baseFunction.minX+transformValue;
			this.maxX=baseFunction.maxX+transformValue;
		}else if(transType==FunctionTransformType.SCALE_X){
			this.minX=baseFunction.minX*transformValue;
			this.maxX=baseFunction.maxX*transformValue;
		} else {
			this.minX=baseFunction.minX;
			this.maxX=baseFunction.maxX;
		}
		leftClosed=baseFunction.leftClosed;
		rightClosed=baseFunction.rightClosed;
		this.isdefined=baseFunction.isdefined;
		isValidExpr=false;
		expr=createExpression();
		super.reCalculate(clipMinX,clipMaxX);
	}
	*/
	
	private String createExpression() {
		if (baseFunction.expr == "")
			return "";
		String s = baseFunction.getExpression();
		if (transType == FunctionTransformType.TRANSLATE_X) {
			s.replace("x", "x -" + transformValue);
		} else if (transType == FunctionTransformType.TRANSLATE_Y) {
			s = s + " " + transformValue;
		} else if (transType == FunctionTransformType.SCALE_X) {
			s.replace("x", "x/" + transformValue);
		} else if (transType == FunctionTransformType.SCALE_Y) {
			s = "(" + s + ")*" + transformValue;
		} else {
			s="";
		}
		return s;
	}
	
	@Override()
	public double getY(double x){
		if (!this.isdefined) return Double.NaN;
		if (!isInDomain(x)) return Double.NaN;
		double y;
		if (transType==FunctionTransformType.TRANSLATE_X){
			y=baseFunction.getY(x-transformValue);
		}else if(transType==FunctionTransformType.TRANSLATE_Y){
			y=baseFunction.getY(x)+transformValue;
		}else if(transType==FunctionTransformType.SCALE_X){
			y=baseFunction.getY(x/transformValue);
		}else if(transType==FunctionTransformType.SCALE_Y){
			y=baseFunction.getY(x)*transformValue;
		}else{
			y=Double.NaN;
		}

		return y;
	}
	
	@Override
	public TransformedFunction2D subCurve(double t0, double t1) {
		if (t0< this.minX || t1>this.maxX) return null;
		Function2D f=this.baseFunction.subCurve(t0, t1);
		return new TransformedFunction2D(f,this.transType,this.transformValue);
	}

}
