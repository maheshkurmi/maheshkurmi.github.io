package math.geom2d.line;

import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.Path2D;

import math.geom2d.AffineTransform2D;
import math.geom2d.Point2D;
import math.geom2d.Shape2D;
import math.geom2d.Vector2D;

public class VectorLine2D extends LineSegment2D{
	private  float arrowSize=7f;

	/**
	 * @return the arrowSize
	 */
	public  float getArrowSize() {
		return arrowSize;
	}

	/**
	 * @param arrowSize the arrowSize to set
	 */
	public  void setArrowSize(float arrowSize) {
		this.arrowSize = arrowSize;
	}

	public VectorLine2D(double x1, double y1, double x2, double y2) {
		super(x1, y1,x2,y2);
	}

	public VectorLine2D(Point2D point, Vector2D dir) {
		super(point, point.plus(dir));
	}

	public VectorLine2D(Point2D point1, Point2D point2) {
		super(point1, point2);
	}

	public Vector2D getDir(){
		return new Vector2D(dx,dy).normalize();
	}
     
    public VectorLine2D createUnitVector(){
    	return new VectorLine2D(this.firstPoint(),getDir());
    }

    public Vector2D getVector(){
		return new Vector2D(firstPoint(),lastPoint());
    	
    }
    @Override
   	public VectorLine2D transform(AffineTransform2D trans) {
   		double[] tab = trans.coefficients();
   		double x1 = x0 * tab[0] + y0 * tab[1] + tab[2];
   		double y1 = x0 * tab[3] + y0 * tab[4] + tab[5];
   		double x2 = (x0 + dx) * tab[0] + (y0 + dy) * tab[1] + tab[2];
   		double y2 = (x0 + dx) * tab[3] + (y0 + dy) * tab[4] + tab[5];
   		VectorLine2D v= new VectorLine2D(x1, y1, x2, y2);
   		v.setArrowSize(arrowSize);
   		return v;
   	}
    // =================================
    // Methods implementing the Shape interface

    /**
     * Appends a line to the current path.
     * 
     * @param path the path to modify
     * @return the modified path
     */
	public Path2D appendPath(Path2D path) {
		double l=this.length();
		if (l<Shape2D.ACCURACY)return path;
		if (l<arrowSize) return super.appendPath(path);
		Vector2D v = getDir().times(arrowSize);
		Point2D p = lastPoint().minus(v);
		Point2D p1=p.plus(v.rotate(Math.PI/2));
		Point2D p2=p.plus(v.rotate(-Math.PI/2));
		
		
		path.lineTo((float) x0 + dx, (float) y0 + dy);
		path.moveTo(p1.x, p1.y);
		path.lineTo((float) x0 + dx, (float) y0 + dy);
		path.moveTo(p2.x, p2.y);
		path.lineTo((float) x0 + dx, (float) y0 + dy);

		return path;
	}

	/**
	 * deprecated
	 */
	public Path2D getGeneralPath() {
		Path2D path = new Path2D.Double();
		double l=this.length();
		if (l<Shape2D.ACCURACY)return path;
		if (l<arrowSize) return super.appendPath(path);
		Vector2D v = getDir().times(arrowSize);
		Point2D p = lastPoint().minus(v);
		Point2D p1=p.plus(v.rotate(2*Math.PI/3));
		Point2D p2=p.plus(v.rotate(-2*Math.PI/3));
	
		path.moveTo((float) x0, (float) y0);
		path.lineTo((float) x0 + dx, (float) y0 + dy);
		path.moveTo(p1.x, p1.y);
		path.lineTo((float) x0 + dx, (float) y0 + dy);
		path.moveTo(p2.x, p2.y);
		path.lineTo((float) x0 + dx, (float) y0 + dy);

		return path;
	}  
	
	@Override
	public Shape asAwtShape() {
		// Check that the curve is bounded
        return this.getGeneralPath();
	}
	@Override
	public void draw(Graphics2D g2) {
		g2.draw(this.asAwtShape());
	}
	
	
}
