package math.geom2d.polygon;

import math.geom2d.Point2D;
import math.geom2d.Vector2D;
import math.geom2d.conic.Circle2D;
import math.geom2d.line.LineSegment2D;
import math.geom2d.line.StraightLine2D;

/**
 * 
 * @author mahesh
 *
 */
public class Triangle2D extends SimplePolygon2D {
	 
    
    /**
	 * constructor, specifying vertices of triangle
	 * dimensions.  
	 */
    public Triangle2D(double x0, double y0, double x1, double y1, double x2, double y2) {
        super(new Point2D[]{new Point2D(x0,y0),new Point2D(x1,y1),new Point2D(x2,y2) });
    }

    /**
	 * constructor, specifying vertices of triangle
	 * dimensions.  
	 */
    public Triangle2D(Point2D point1, Point2D point2, Point2D point3) {
    	super(point1,point2,point3);
    }


	/*

	public void reverse() {
		//swap first and last vertex
		Point2D pt=vertex(2);
		setVertex(2,vertex(0));
		setVertex(0,pt);
		reverse=!reverse;
	}
*/
	


	@Override
	public void addVertex(Point2D point) {
		throw new UnsupportedOperationException("No More Vertices can be added to triangle");
		
	}

	@Override
	public void insertVertex(int index, Point2D point) {
		throw new UnsupportedOperationException("No More Vertices can be added to triangle");
		
	}

	@Override
	public void removeVertex(int index) {
		throw new UnsupportedOperationException(" Vertices can not be removed from triangle");
		
	}
	
    public boolean removeVertex(Point2D point) {
    	throw new UnsupportedOperationException(" Vertices can not be removed from triangle");
    }


	@Override
	public int vertexNumber() {
			return 3;
	}

	@Override
	public int closestVertexIndex(Point2D point) {
		double minDist = Double.POSITIVE_INFINITY;
    	int index = -1;
    	
    	int i = 0;
    	for (Point2D vertex : vertices) {
    		double dist = vertex.distance(point);
    		if (dist < minDist) {
    			index = i;
    			minDist = dist;
    		}
    		i++;
    	}
    	
    	return index;
	}

	@Override
	public int edgeNumber() {
		return 3;
	}

	@Override
	public Point2D centroid() {
		return Point2D.centroid(vertices);
	}

	
	
	/**
	 * returns index corressponding to point 
	 * @param point
	 * @return
	 */
	private int getVertexIndex(Point2D point){
		int i;
		if (vertex(0).equals(point)) i= 0;
		else if (vertex(1).equals(point)) i= 1;
		else if (vertex(2).equals(point)) i= 2;
		else i=-1;
		return i;
		
	}
	
	/**
	 * returns line opposite to vertex at position index
	 * @param index position of vertex 0<=index<=2
	 * @return returns null if (indexi > 2  or index<0)
	 */
	public LineSegment2D getEdge(int index){
		
		   switch (index) {
	        case 0:
	            return new LineSegment2D(vertex(1),vertex(2));
	        case 1:
	        	return new LineSegment2D(vertex(2), vertex(0));
	        case 2:
	        	return new LineSegment2D(vertex(0), vertex(1));
	        default:
	            return null;
	        }
	}
	
	 /**
     * Returns the polygon created by reversing the order of the vertices.
     */
    public Triangle2D complement() {
        int nPoints = this.vertices.size();

        Point2D[] res = new Point2D[nPoints];

       if (nPoints>0)
           res[0] = this.vertices.get(0);

        for (int i = 1; i<nPoints; i++) {
            res[i] = this.vertices.get(nPoints-i);
        }
        return new Triangle2D(res[0],res[1],res[2]);
    }
    
	/**
	 * returns length of  edge opposite to vertex
	 * @param point
	 * @return
	 */
	public double getSide(int index){
		  if (index<0 || index>2) return 0;
		  return getEdge(index).length();
	}
	
	public double getAngle(int index){
		Point2D A=vertex(index);
		Point2D B=vertex((index+1) % 3 );
		Point2D C=vertex((index+2) % 3 );
	    Vector2D v1=new Vector2D(A,B);
	    Vector2D v2=new Vector2D(A,C);
	    return Math.acos(v1.dot(v2)/(v1.norm()*v2.norm()));
	    
	}
	
	public double getSemiPerimeter(){
		return 0.5*(this.getSide(0)+this.getSide(1)+this.getSide(2));
	}
	
	/**
	 * returns edge opposite to
	 * @param point
	 * @return
	 */
	public LineSegment2D getEdge(Point2D point){
		  int i=getVertexIndex( point);
		  if (i<0 || i>2)return null;
		  return getEdge(i);
	}

	/**
	 * returns altitude from specified index
	 * @param index position of vertex 0<=index<=2
	 * @return returns null if (indexi > 2  or index<0) or altitude lies outside the triangle
	 */
	public LineSegment2D getAltitude(int index){
		   if (index>2 || index<0)return null ;
		   //find edge opposite to vertex
		   LineSegment2D edge=getEdge(index);
		   //find feet of point on opposite edge
		   Point2D p =edge.projectedPoint(vertex(index));
		   if (p==null || !edge.contains(p)) return null;
		   return new LineSegment2D(vertex(index),p);
	}
	
	/**
	 * returns altitude from specified index
	 * @param index position of vertex 0<=index<=2
	 * @return returns null if (indexi > 2  or index<0)
	 */
	public LineSegment2D getAltitudeLine(int index){
		   if (index>2 || index<0)return null ;
		   //find line opposite to vertex
		   StraightLine2D base=new StraightLine2D(getEdge(index));
		   //find feet of point on opposite edge
		   Point2D p =base.projectedPoint(vertex(index));
		   return new LineSegment2D(vertex(index),p);
	}
	
	/**
	 * returns Median from specified index
	 * @param index position of vertex 0<=index<=2
	 * @return returns null if (indexi > 2  or index<0)
	 */
	public LineSegment2D getMedian(int index){
		   if (index>2 || index<0)return null ;
		   //find line opposite to vertex
		   LineSegment2D base=getEdge(index);
		   return new LineSegment2D(vertex(index),Point2D.midPoint(base.firstPoint(),base.lastPoint()));
	}
	
	/**
	 * returns Angle bisector from specified index
	 * @param index position of vertex 0<=index<=2
	 * @return returns null if (indexi > 2  or index<0)
	 */
	public LineSegment2D getAngleBisector(int index){
		  if (index>2 || index<0)return null ;
		Point2D A=vertex(index);
		Point2D B=vertex((index+1) % 3 );
		Point2D C=vertex((index+2) % 3 );
		double AB=A.distance(B);
		double AC=A.distance(C);
		if (AB==0 || AC==0) return new LineSegment2D(A,A);
		double k=AB/AC;
		Point2D p; //point on opposite base corressponding to point of intersection of angle bisector
		p=Point2D.interpolate(B, C, k);
		return new LineSegment2D(vertex(index),p);
	}
	
	/**
	 * returns Angle bisector from specified index
	 * @param index position of vertex 0<=index<=2
	 * @return returns null if (index > 2  or index<0)
	 */
	public StraightLine2D getExtAngleBisector(int index){
		 if (index>2 || index<0)return null ;
		return getAngleBisector(index).perpendicular(vertex(index));
	}
	
	/**
	 * returns Perpendicular bisector of edge opposite to specified index
	 * @param index position of vertex 0<=index<=2
	 * @return returns null if (index > 2  or index<0)
	 */
	public StraightLine2D getPerpendicularBisector(int index){
		   if (index>2 || index<0)return null ;
		   //find line opposite to vertex
		   LineSegment2D base=getEdge(index);
		   return base.getMedian();
	}
	
	
	public Point2D getCentroid(){
		return this.centroid();
	}
	

	public Circle2D getCircumCIrcle(){
		return Circle2D.circumCircle(vertices.get(0),vertices.get(1),vertices.get(2));
	}
	
	public double getCircumRadius(){
		return getCircumCIrcle().radius();
	}
	
	public Circle2D getInCIrcle(){
		Point2D c=this.getInCentre();
		double r= getEdge(0).distance(c);
		return new Circle2D(c,r);
	}
	
	public double getInRadius(){
		Point2D c=this.getInCentre();
		return getEdge(0).distance(c);
	}
	
	public Point2D getExCentre(int index){
		if (index>2 || index<0)return null ;
		StraightLine2D line1=getExtAngleBisector((index+1) % 3);
		StraightLine2D line2=getExtAngleBisector((index+2) % 3);
		return line1.intersection(line2);
	}
	
	public double getExRadius(int index){
		 if (index>2 || index<0)return 0 ;
		 double A =this.area();
		 double s=this.getSemiPerimeter();
		 double a=getSide(index);
		 return A/(s-a);
	}
	
	public Point2D getOrthoCentre(){
		StraightLine2D line1=new StraightLine2D(getAltitudeLine(0));
		StraightLine2D line2=new StraightLine2D(getAltitudeLine(1));
		return line1.intersection(line2);
	}
	
	public Point2D getCircumCentre(){
		StraightLine2D line1=getPerpendicularBisector(0);
		StraightLine2D line2=getPerpendicularBisector(1);
		return line1.intersection(line2);
	}
	
	public Point2D getInCentre(){
		LineSegment2D line1=getAngleBisector(0);
		LineSegment2D line2=getAngleBisector(1);
		
		return line1.intersection(line2);
	}
	
	public Circle2D getExCircle(int index){
		Point2D c=getExCentre(index);
		if (c==null)return null;
		double r=getExRadius(index);
		if (r==0)return null;
		return new Circle2D(c, r);
	}
	
	
	/**
	 * @return returns pedal triangle for this triangle .Returns null if this triangle is not defined (collinear vertices)
	 */
	public Triangle2D getPedalTriangle(){
		if (!isDefined())return null;
		if (!this.contains(getOrthoCentre()))return null;
		Point2D p1=getEdge(0).projectedPoint(vertex(0));
		Point2D p2=getEdge(1).projectedPoint(vertex(1));
		Point2D p3=getEdge(2).projectedPoint(vertex(2));
		return new Triangle2D(p1,p2,p3);
	}
	
	/**
	 * @return returns Excentral triangle for this triangle .Returns null if this triangle is not defined (collinear vertices)
	 */
	public Triangle2D getExcentralTriangle(){
		if (!isDefined())return null;
		Point2D p1=getExCentre(0);
		Point2D p2=getExCentre(1);
		Point2D p3=getExCentre(2);
		return new Triangle2D(p1,p2,p3);
	}
	
	/**
	 * return true if vertices are not collinear
	 * @return
	 */
	public boolean isDefined(){
		return !Point2D.isColinear(vertices.get(0),vertices.get(1),vertices.get(2));
	}
	
}
