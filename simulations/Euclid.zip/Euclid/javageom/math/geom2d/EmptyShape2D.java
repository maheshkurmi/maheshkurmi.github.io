package math.geom2d;

import java.awt.Graphics2D;

public class EmptyShape2D implements Shape2D{

	@Override
	public boolean almostEquals(GeometricObject2D obj, double eps) {
		if (obj instanceof EmptyShape2D) return true;
		return false;
	}

	@Override
	public boolean contains(double x, double y) {
		return false;
	}

	@Override
	public boolean contains(Point2D p) {
		return false;
	}

	@Override
	public double distance(Point2D p) {
		return Double.MAX_VALUE;
	}

	@Override
	public double distance(double x, double y) {
		return Double.MAX_VALUE;
	}

	@Override
	public boolean isBounded() {
		return false;
	}

	@Override
	public boolean isEmpty() {
		return true;
	}

	@Override
	public Box2D boundingBox() {
		return null;
	}

	@Override
	public Shape2D clip(Box2D box) {
		return null;
	}

	@Override
	public Shape2D transform(AffineTransform2D trans) {
		return this;
	}

	@Override
	public void draw(Graphics2D g2) {
		// Nothing to draw
		
	}

}
