package math.geom2d;
	/**
	 * class to represent filled or hollow dots
	 */

public class Dot2D extends Point2D{

	private boolean filled=false;
	public Dot2D(double x, double y, boolean filled){
		super(x,y);
		this.setFilled(filled);
	}
	/**
	 * @return the filled
	 */
	public boolean isFilled() {
		return filled;
	}
	/**
	 * @param filled the filled to set
	 */
	public void setFilled(boolean filled) {
		this.filled = filled;
	}
	

}
