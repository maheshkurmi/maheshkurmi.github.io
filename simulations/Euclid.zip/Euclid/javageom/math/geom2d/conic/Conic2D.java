/* File Conic2D.java 
 *
 * Project : Java Geometry Library
 *
 * ===========================================
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 2.1 of the License, or (at
 * your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but 
 * WITHOUT ANY WARRANTY, without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library. if not, write to :
 * The Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307, USA.
 */

// package

package math.geom2d.conic;

import math.geom2d.AffineTransform2D;
import math.geom2d.Box2D;
import math.geom2d.Point2D;
import math.geom2d.curve.CurveSet2D;
import math.geom2d.domain.Boundary2D;
import math.geom2d.domain.ContinuousOrientedCurve2D;
import math.geom2d.line.LinearShape2D;
import math.geom2d.line.StraightLine2D;

// Imports

/**
 * Interface for all conic curves: parametric conics, or ellipses, parabolas,
 * and hyperbolas. Degenerate conics are also encompassed by this interface.
 */
public interface Conic2D extends Boundary2D {

    // ===================================================================
    // constants

    /**
     * The different types of conic.
     */
    public enum Type {
        /**
         * Degenerate conic, for example a conic given by the equation
         * <code>x^2+1=0</code>)
         */
        NOT_A_CONIC,
        /** Ellipse */
        ELLIPSE,
        /** Hyperbola */
        HYPERBOLA,
        /** Parabola */
        PARABOLA,
        /** Circle */
        CIRCLE,
        /** Straight Line */
        STRAIGHT_LINE,
        /** Union of two lines */
        TWO_LINES,
        /** Single point */
        POINT;
    }

    // ===================================================================
    // class variables

    // ===================================================================
    // constructors

    // ===================================================================
    // accessors

    // type accessors ------------

    public abstract Type conicType();

    /**
     * Returns the coefficient of the Cartesian representation of the conic.
     * Cartesian equation has the form :
     * <p>
     * a*x^2 + b*x*y + c*y^2 + d*x + e*y + f
     * <p>
     * The length of the array is then of size 6.
     */
    public abstract double[] conicCoefficients();

    /**
     * Returns the eccentricity of the conic.
     */
    public abstract double eccentricity();


    /**
     * Returns the centre of the conic (Returns centre for central conic)
     */
    public abstract Point2D center();

    /**
     * Returns the foot of point on the conic (Nearest orthogonal point on curve is obtained by
     * getting point of intersection of normal from the point)
     */
    public abstract Point2D getFootOfPoint(Point2D point);


    /**
     * returns array of normal from point on conic
     * @param point
     * @return non null array of Point2D (size of array is zero if no tangents are possible)
     */
    public abstract Point2D[] getFeetOfNormals(Point2D point);

    
    /**
     * returns array of feet of normals from point on conic
     * @param point
     * @return non null array of Point2D (size of array is zero if no tangents are possible)
     */
    public abstract Point2D[] getFeetOfTangents(Point2D point);

    /**
     * returns tangent on this conic at point
     * @param t algebric parameter corresponding to point t
     * @return
     */
    public abstract StraightLine2D getTangentAt_t(double t);
    
    /**
     * returns array of feet of tangents parallel to given line
     * @param line Line parallel to which tangents are to be drawn
     * @return non null array of Point2D (size of array is zero if no tangents are possible)
     */
    public abstract Point2D[] getFeetOfParallelTangents(LinearShape2D line);

   
    /**
     * returns array of feet of normals parallel to given line
     * @param line Line parallel to which normals are to be drawn
     * @return non null array of Point2D (size of array is zero if no tangents are possible)
     */
    public abstract Point2D[] getFeetOfParallelNormals(LinearShape2D line);

    
    /**
     * Returns non null array containing points of intersections of this conic with conic
     * @param conic Conic which intersects with this conic
     * @return non null array containing points of intersections
     */
    public abstract Point2D[] getIntersections(Conic2D conic);

   
   /**
    * returns tangent circle at foot of given point on curve
    * @param point 
    * @return returns null if tangent circle cant be found (eg point is singular or curve is straight)
    */
    public abstract Circle2D getOscullatingCitcle(Point2D point);
    
    // ===================================================================
    // modifiers

    public abstract Conic2D reverse();

    public abstract Conic2D transform(AffineTransform2D trans);

    public abstract CurveSet2D<? extends ContinuousOrientedCurve2D> clip(
            Box2D box);
    /**
     * Compute intersections of the conic with other conic
     */
  //  public Collection<Point2D> intersections(Conic2D conic);
}