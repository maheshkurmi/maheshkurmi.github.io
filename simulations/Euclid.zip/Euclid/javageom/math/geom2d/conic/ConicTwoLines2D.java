package math.geom2d.conic;

import java.util.Collection;

import math.geom2d.AffineTransform2D;
import math.geom2d.Point2D;
import math.geom2d.domain.ContourArray2D;
import math.geom2d.line.LinearShape2D;
import math.geom2d.line.StraightLine2D;

 public class ConicTwoLines2D extends ContourArray2D<StraightLine2D>
            implements Conic2D {

        double xc = 0, yc = 0, d = 1, theta = 0;

        public ConicTwoLines2D(Point2D point, double d, double theta) {
            this(point.x(), point.y(), d, theta);
        }

        public ConicTwoLines2D(double xc, double yc, double d, double theta) {
            super();

            this.xc = xc;
            this.yc = yc;
            this.d = d;
            this.theta = theta;

            StraightLine2D baseLine = new StraightLine2D(
                    new Point2D(xc, yc), theta);
            this.add(baseLine.parallel(d));
            this.add(baseLine.parallel(-d).reverse());
        }

        public ConicTwoLines2D(StraightLine2D line1,StraightLine2D line2) {
            super();
            this.add(line1);
            this.add(line2);
            Point2D centre=line1.intersection(line2);
            if(centre==null){
            	double[] d1=line1.cartesianEquation();
            	double[] d2=line2.cartesianEquation();
            	if (d1[0]!=0){
            		centre=new Point2D(d1[2]/(2*d1[0])+d2[2]/(2*d2[0]),0);
            	}else if (d1[1]!=0){
            		centre=new Point2D(0,d1[2]/(2*d1[1])+d2[2]/(2*d2[1]));
            	}else{
            		centre=new Point2D();
            	}
            }
            this.xc = centre.x;
            this.yc = centre.y;
            this.theta = (line1.horizontalAngle()+line2.horizontalAngle())/2;
         }
        
        public StraightLine2D getLine1(){
        	if (this.size()>0)return this.get(0);
        	return null;
        }
        
        public StraightLine2D getLine2(){
        	if (this.size()==1)return this.get(0);
        	if (this.size()==2)return this.get(1);
        	return null;
        	
        }
        
        public double[] conicCoefficients() {
            double[] coefs = { 0, 0, 1, 0, 0, -1 };
         	double[] d1=this.getLine1().cartesianEquation();
        	double[] d2=this.getLine2().cartesianEquation();
        	coefs[0]=d1[0]*d2[0];
        	coefs[1]=d1[0]*d2[1]+d1[1]*d2[0];
        	coefs[2]=d1[1]*d2[1];
        	coefs[3]=d1[0]*d2[2]+d1[2]*d2[0];
        	coefs[4]=d1[1]*d2[2]+d1[2]*d2[1];
        	coefs[5]=d1[2]*d2[2];
        	return coefs;
            /*
            AffineTransform2D sca = AffineTransform2D.createScaling(0, d);
            AffineTransform2D rot = AffineTransform2D.createRotation(theta);
            AffineTransform2D tra = AffineTransform2D.createTranslation(xc, yc);
            
            // AffineTransform2D trans = tra.compose(rot).compose(sca);
            AffineTransform2D trans = sca.chain(rot).chain(tra);
            return Conics2D.transform(coefs, trans);
            */
        }

        public Type conicType() {
            return Conic2D.Type.TWO_LINES;
        }

        public double eccentricity() {
            return Double.NaN;
        }

        @Override
        public ConicTwoLines2D transform(AffineTransform2D trans) {
        	StraightLine2D l1=this.getLine1().transform(trans);
        	StraightLine2D l2=this.getLine2().transform(trans);
        	return new ConicTwoLines2D(l1,l2);
        	/*
            Point2D center = new Point2D(xc, yc).transform(trans);
            StraightLine2D line = this.firstCurve().transform(trans);

            double dist = line.distance(center);
            double angle = line.horizontalAngle();
            return new ConicTwoLines2D(center, dist, angle);
            */
        }

        @Override
        public ConicTwoLines2D reverse() {
        	return new ConicTwoLines2D(this.getLine1().reverse(),this.getLine2().reverse());
            //return new ConicTwoLines2D(xc, yc, -d, theta);
        }

		
		/**returns point of intesection of constituent lines
		 * @see math.geom2d.conic.Conic2D#center()
		 */
        @Override
		public Point2D center() {
			// TODO Auto-generated method stub
			return new Point2D(xc,yc);
		}
        
        @Override
    	public Point2D getFootOfPoint(Point2D point) {
    		double t1;
    		t1=this.getLine1().project(point);
    		Point2D point1=this.getLine1().point(t1);
    		
    		double t2;
    		t2=this.getLine2().project(point);
    		Point2D point2=this.getLine2().point(t2);
    		//return nearer point
    		if (point.distance(point1)<point.distance(point2))
    			return point1;
    		else
    			return point2;
    	}

		@Override
		public Point2D[] getFeetOfNormals(Point2D point) {
			double t1;
    		t1=this.getLine1().project(point);
    		Point2D point1=this.getLine1().point(t1);
    		
    		double t2;
    		t2=this.getLine2().project(point);
    		Point2D point2=this.getLine2().point(t2);
    		
    		return new Point2D[]{point1,point2};
		}

		@Override
		public Point2D[] getFeetOfTangents(Point2D point) {
			return null;
		}

		@Override
		public Circle2D getOscullatingCitcle(Point2D point) {
			return null;
		}

		@Override
		public Point2D[] getFeetOfParallelTangents(LinearShape2D line) {
			return new Point2D[0];
		}

		@Override
		public Point2D[] getFeetOfParallelNormals(LinearShape2D line) {
			return new Point2D[0];
		}

		@Override
		public Point2D[] getIntersections(Conic2D conic) {
			Collection<Point2D> pts;
			pts=conic.intersections(this.getLine1());
			pts.addAll(conic.intersections(getLine2()));
			return pts.toArray(new Point2D[0]);
		}

		@Override
		public StraightLine2D getTangentAt_t(double t) {
			// TODO Auto-generated method stub
			return null;
		}
    }