package math.geom2d.conic;
import math.geom2d.AffineTransform2D;
import math.geom2d.Point2D;
import math.geom2d.line.LinearShape2D;
import math.geom2d.line.StraightLine2D;

public class ConicStraightLine2D extends StraightLine2D implements Conic2D {

    double[] coefs = new double[] { 0, 0, 0, 1, 0, 0 };

    public ConicStraightLine2D(StraightLine2D line) {
        super(line);
		coefs = new double[] { 0, 0, 0, dy, -dx, dx * y0 - dy * x0 };
    }

    public ConicStraightLine2D(double a, double b, double c) {
        super(StraightLine2D.createCartesian(a, b, c));
        coefs = new double[] { 0, 0, 0, a, b, c };
    }

    public double[] conicCoefficients() {
        return coefs;
    }

    public Type conicType() {
        return Conic2D.Type.STRAIGHT_LINE;
    }

    /** Return NaN. */
    public double eccentricity() {
        return Double.NaN;
    }

    @Override
    public ConicStraightLine2D reverse() {
        return new ConicStraightLine2D(super.reverse());
    }

    @Override
    public ConicStraightLine2D transform(AffineTransform2D trans) {
        return new ConicStraightLine2D(super.transform(trans));
    }

	@Override
	public Point2D center() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Point2D getFootOfPoint(Point2D point) {
		double t;
		t=project(point);
		return point(t);
	}

	@Override
	public Point2D[] getFeetOfNormals(Point2D point) {
		return  new Point2D[]{getFootOfPoint( point)};
	}

	@Override
	public Point2D[] getFeetOfTangents(Point2D point) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Circle2D getOscullatingCitcle(Point2D point) {
		return null;
	}

	@Override
	public Point2D[] getFeetOfParallelTangents(LinearShape2D line) {
		return new Point2D[0];
	}

	@Override
	public Point2D[] getFeetOfParallelNormals(LinearShape2D line) {
		return new Point2D[0];
	}

	@Override
	public Point2D[] getIntersections(Conic2D conic) {
		return conic.intersections(this).toArray(new Point2D[0]);
	}

	@Override
	public StraightLine2D getTangentAt_t(double t) {
		// TODO Auto-generated method stub
		return null;
	}
}
