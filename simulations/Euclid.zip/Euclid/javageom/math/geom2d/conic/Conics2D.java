/**
 * 
 */

package math.geom2d.conic;
import static java.lang.Math.*;

import java.util.ArrayList;

import util.CurveUtils;


import math.geom2d.AffineTransform2D;
import math.geom2d.Angle2D;
import math.geom2d.Point2D;
import math.geom2d.Shape2D;
import math.geom2d.Vector2D;
import math.geom2d.line.LineSegment2D;
import math.geom2d.line.LinearShape2D;
import math.geom2d.line.StraightLine2D;
import math.utils.EquationUtils;
import math.utils.Matrix;
import math.utils.Matrix33;

/**
 * Generic class providing utilities for manipulating conics. Provides in
 * particular methods for reducing a conic.
 * 
 * @author mahesh kurmi
 */
public class Conics2D {

	public final static Conic2D reduceConic(double a,double b,double c,double d,double e,double f) {
		return reduceConic(new double[]{a,b,c,d,e,f});
	}
			
    // precision for tests
    private static double  eps = Shape2D.ACCURACY;

	//returns conic based on general 2 degree equation
    public final static Conic2D reduceConic(double[] coefs) {
		if (coefs.length < 6) {
            System.err.println(
            		"Conic2DUtils.reduceConic: must provide 6 coefficients");
            return null;
        }
        boolean debug = false;

        // Extract coefficients
        double a = coefs[0];
        double b = coefs[1];
        double c = coefs[2];
        double d = coefs[3];
        double e = coefs[4];
        double f = coefs[5];

        // Transform the generic conic into a conic symmetric with respect to
        // one of the basis axes.
        // This results in fixing the coefficient b to 0.

        // coefficients of transformed conic;
        double a1, b1, c1, d1, e1, f1;

        //return single straightline if all 2 degree terms are zero
        if (abs(a)<eps && abs(b)<eps && abs(c) <eps) {
        	return new ConicStraightLine2D(StraightLine2D.createCartesian(d, e, f));
        }
        
        //check if conic can be resolved in two linear factors
        double D=a*c*f+e*d*b/4-a*e*e/4-c*d*d/4-f*b*b/4;
        if (abs(D)<eps){
        	return tryToCreatePairOfLines(coefs);
        }
 
        Conic2D conic=tryToCreateCircle(coefs);
        if (conic!=null)return conic;

        double theta0 = 0;
        // Check if b is zero
		if (abs(b) < eps) {
            // Simply keep the same coefficients
            a1 = a;
            b1 = b;
            c1 = c;
            d1 = d;
            e1 = e;
            f1 = f;
            theta0 = 0;
            // Test degenerate cases
     		if (abs(a) < eps && abs(c) < eps) {
     			if (abs(d) > eps || abs(e) > eps)
     				return new ConicStraightLine2D(d, e, f);
     			else
     				return null; // TODO: throw exception ?
             }

        } else {
            // determine rotation angle (between 0 and PI/2).
			if (abs(a - c) < eps)
				theta0 = PI / 4; // conic symmetric wrt diagonal
			else
				theta0 = Angle2D.formatAngle(atan2(b, a - c) / 2);

			if (debug)
				System.out.println("conic main angle: " + toDegrees(theta0));

			// computation shortcuts
			double cot = cos(theta0);
			double sit = sin(theta0);
			double co2t = cos(2 * theta0);
			double si2t = sin(2 * theta0);
			double cot2 = cot * cot;
			double sit2 = sit * sit;

			// Compute coefficients of the conic rotated around origin
			a1 = a * cot2 + b * sit * cot + c * sit2;
			b1 = si2t * (c - a) + b * co2t; // should be equal to zero
			c1 = a * sit2 - b * sit * cot + c * cot2;
			d1 = d * cot + e * sit;
			e1 = -d * sit + e * cot;
			f1 = f;
        }

        // small control on the value of b1
		if (abs(b1) > eps) {
            System.err.println(
            		"Conic2DUtils.reduceConic: " + 
            		"conic was not correctly transformed");
            return null;
        }

		
        // Case of a parabola
		if (abs(a1) < eps) {
            // case of a1 close to 0 -> parabola parallel to horizontal axis
            if (debug)
                System.out.println("horizontal parabola");

			// Check degenerate case d=0
			if (abs(d1) < eps) {
				double delta = e1 * e1 - 4 * c1 * f1;
				if (delta >= 0) {
					// find the 2 roots
					double ys = -e1 / 2.0 / c1;
					double dist = sqrt(delta) / 2.0 / c1;
					Point2D center = new Point2D(0, ys)
							.transform(AffineTransform2D.createRotation(theta0));
					return new ConicTwoLines2D(center, dist, theta0);
				} else
					return null; // TODO: throw exception ?
            }

            // compute reduced coefficients
			double c2 = -c1 / d1;
			double e2 = -e1 / d1;
			double f2 = -f1 / d1;

            // vertex of the parabola
			double xs = -(e2 * e2 - 4 * c2 * f2) / (4 * c2);
			double ys = -e2 * .5 / c2;
            
            // create and return result
			return new Parabola2D(xs, ys, c2, theta0 - PI / 2);

		} else if (abs(c1) < eps) {
			// Case of c1 close to 0 -> parabola parallel to vertical axis
			if (debug)
				System.out.println("vertical parabola");

            // Check degenerate case d=0
			if (abs(e1) < eps) {
				double delta = d1 * d1 - 4 * a1 * f1;
				if (delta >= 0) {
					// find the 2 roots
					double xs = -d1 / 2.0 / a1;
					double dist = sqrt(delta) / 2.0 / a1;
					Point2D center = new Point2D(0, xs)
							.transform(AffineTransform2D.createRotation(theta0));
					return new ConicTwoLines2D(center, dist, theta0);
				} else
					return null; // TODO: throw exception ?
			}

			// compute reduced coefficients
			double a2 = -a1 / e1;
			double d2 = -d1 / e1;
			double f2 = -f1 / e1;

			// vertex of parabola
			double xs = -d2 * .5 / a2;
			double ys = -(d2 * d2 - 4 * a2 * f2) / (4 * a2);

			// create and return result
			return new Parabola2D(xs, ys, a2, theta0);
        }

        // Remaining cases: ellipse or hyperbola

        // compute coordinate of conic center
		Point2D center = new Point2D(-d1 / (2 * a1), -e1 / (2 * c1));
		center = center.transform(AffineTransform2D.createRotation(theta0));

		// length of semi axes
		double num = (c1 * d1 * d1 + a1 * e1 * e1 - 4 * a1 * c1 * f1)
				/ (4 * a1 * c1);
		double at = num / a1;
		double bt = num / c1;

		if (at < 0 && bt < 0) {
			System.err.println("Conic2DUtils.reduceConic(): found A<0 and C<0");
			return null;
        }

        // Case of an ellipse
		if (at > 0 && bt > 0) {
			if (debug)
				System.out.println("ellipse");
			if (at > bt)
				return new Ellipse2D(center, sqrt(at), sqrt(bt), theta0);
			else
				return new Ellipse2D(center, sqrt(bt), sqrt(at),
						Angle2D.formatAngle(theta0 + PI / 2));
        }

        // remaining case is the hyperbola

		// Case of east-west hyperbola
		if (at > 0) {
			if (debug)
				System.out.println("east-west hyperbola");
			return new Hyperbola2D(center, sqrt(at), sqrt(-bt), theta0);
		} else {
			if (debug)
				System.out.println("north-south hyperbola");
			return new Hyperbola2D(center, sqrt(bt), sqrt(-at), theta0 + PI / 2);
        }
    }
    
    private static Conic2D tryToCreateCircle(double[] coefs){
    	  // precision for tests
        double eps = Shape2D.ACCURACY;

        // Extract coefficients
        double a = coefs[0];
        double b = coefs[1];
        double c = coefs[2];
        double d = coefs[3];
        double e = coefs[4];
        double f = coefs[5];
        
        if(abs(b)>eps) return null;
        b=0;
        
        if (a==c) {
        	d=d/a;
        	e=e/a;
        	f=f/a;
        	double r=d*d/4+e*e/4-f;
        	if (r<0) return null;
        	return new Circle2D(-d/2,-e/2,sqrt(r));
        }
        return null;
    }

    private static Conic2D tryToCreatePairOfLines(double[] coefs){
  	  // precision for tests
      double eps = Shape2D.ACCURACY;

      // Extract coefficients of form ax2+2*hxy+by2+2gx+2fy+c=0
      double a = coefs[0];
      double h = coefs[1]/2;
      double b = coefs[2];
      double g = coefs[3]/2;
      double f = coefs[4]/2;
      double c = coefs[5];
     
      
      //find slopes
      double[] m=new double[2];
      int n=EquationUtils.SolveQuadratic(b, 2*h, a,m);
      if (n==0)return null;
      
      if (n==1){
    	  if (Double.isInfinite(m[0])){ //both lines of form x=c1, x=c2
    		  double[] roots=new double[2];
    		  int k= EquationUtils.SolveQuadratic(1, 2*g/a, c/a,roots);
    		  if (k<2)return null;
    		  StraightLine2D line1=StraightLine2D.createCartesian(1, 0, -roots[0]);
    		  StraightLine2D line2=StraightLine2D.createCartesian(1, 0, -roots[1]);
    		  return new ConicTwoLines2D(line1,line2);
    	  }else if (abs(m[0])<eps){ //both lines of form y=c1, y=c2
        	  double[] roots=new double[2];
        	  int k= EquationUtils.SolveQuadratic(1, 2*f/b, c/b,roots);
        	  if (k<2)return null;
        	  StraightLine2D line1=StraightLine2D.createCartesian(0, 1, -roots[0]);
        	  StraightLine2D line2=StraightLine2D.createCartesian(0, 1, -roots[1]);
        	  return new ConicTwoLines2D(line1,line2);
    	  }else{ //both lines are parallel and of form y=m[0]x+c1,y=m[0]x+c2
    		  double[] roots=new double[2];
    		  int k= EquationUtils.SolveQuadratic(1, 2*f/b, c/b,roots);
    		  if (k<2)return null;
    		  StraightLine2D line1=StraightLine2D.createCartesian(-m[0], 1, -roots[0]);
    		  StraightLine2D line2=StraightLine2D.createCartesian(-m[0], 1, -roots[1]);
    		  return new ConicTwoLines2D(line1,line2);
    	  }
      }else if (n==2){
    	  if (Double.isInfinite(m[0])){ //Both roots infinity (lines are of form x=c1 and x=c2
    		  double[] roots=new double[2];
    		  int k= EquationUtils.SolveQuadratic(1, 2*g/a, c/a,roots);
    		  if (k<2)return null;
    		  StraightLine2D line1=StraightLine2D.createCartesian(1, 0, -roots[0]);
    		  StraightLine2D line2=StraightLine2D.createCartesian(1, 0, -roots[1]);
    		  return new ConicTwoLines2D(line1,line2);
    		  /*
    		  f=f*(-m[1])/a;
    		  g=g*(-m[1])/a;
    		  StraightLine2D line1=StraightLine2D.createCartesian(1, 0, 2*f);
    		  StraightLine2D line2=StraightLine2D.createCartesian(-m[1], 1, 2*f*m[1]+2*g);
    		  return new ConicTwoLines2D(line1,line2);
    	 	*/
    	  }else if (Double.isInfinite(m[1])){//first root in non infinity other is infinity (lines are of form y=mx+c and x=c
    		  f=f*(-m[0])/a;
    		  g=g*(-m[0])/a;
       		  StraightLine2D line1=StraightLine2D.createCartesian(1, 0, 2*f);
    		  StraightLine2D line2=StraightLine2D.createCartesian(-m[0], 1, 2*f*m[0]+2*g);
    		  return new ConicTwoLines2D(line1,line2);
    	  }else if (m[0]==0){//lines are y=c1 and y=mx+c2
    		  f=f/(b);
    		  g=g/(b);
       		  StraightLine2D line1=StraightLine2D.createCartesian(0, 1, -2*g/m[1]);
    		  StraightLine2D line2=StraightLine2D.createCartesian(-m[1], 1, 2*f+2*g/m[1]);
    		  return new ConicTwoLines2D(line1,line2);
    	  }else if (m[1]==0){//lines are y=mx+c2 and y=c1 
    		  f=f/(b);
    		  g=g/(b);
    		  StraightLine2D line1=StraightLine2D.createCartesian(0, 1, -2*g/m[0]);
        	  StraightLine2D line2=StraightLine2D.createCartesian(-m[0], 1, 2*f+2*g/m[0]);
        	  return new ConicTwoLines2D(line1,line2);
       	  }else { //lines are y=m1x+c1 and y=m2x+c2
    		  double m1,m2,c1,c2;
    		  m1=m[0];
    		  m2=m[1];
    		  f=f/b;
    		  g=g/b;
    		  c2=(2*f*m2+2*g)/(m1-m2);
    		  c1=-2*f-c2;
    		  StraightLine2D line1=StraightLine2D.createCartesian(-m[0], 1, -c1);
    		  StraightLine2D line2=StraightLine2D.createCartesian(-m[1], 1, -c2);
    		  return new ConicTwoLines2D(line1,line2);
    	  }
    	  
      }
      
      return null;
  }
    /**
     * Transforms a conic centered around the origin, by dropping the
     * translation part of the transform. The array must be contains at least
     * 3 elements. If it contains 6 elements, the 3 remaining elements are
     * supposed to be 0, 0, and -1 in that order.
     * 
     * @param coefs an array of double with at least 3 coefficients
     * @param trans an affine transform
     * @return an array of double with as many elements as the input array
     */
    public final static double[] transformCentered(double[] coefs,
            AffineTransform2D trans) {
        // Extract transform coefficients
        double[][] mat = trans.affineMatrix();
        double a = mat[0][0];
        double b = mat[1][0];
        double c = mat[0][1];
        double d = mat[1][1];

        // Extract first conic coefficients
        double A = coefs[0];
        double B = coefs[1];
        double C = coefs[2];

        // compute matrix determinant
		double delta = a * d - b * c;
		delta = delta * delta;

		double A2 = (A * d * d + C * b * b - B * b * d) / delta;
		double B2 = (B * (a * d + b * c) - 2 * (A * c * d + C * a * b)) / delta;
		double C2 = (A * c * c + C * a * a - B * a * c) / delta;

        // return only 3 parameters if needed
        if (coefs.length==3)
            return new double[] { A2, B2, C2 };

        // Compute other coefficients
		double D = coefs[3];
		double E = coefs[4];
		double F = coefs[5];
		double D2 = D * d - E * b;
		double E2 = E * a - D * c;
        return new double[] { A2, B2, C2, D2, E2, F };
    }

    /**
     * Transforms a conic by an affine transform.
     * 
     * @param coefs an array of double with 6 coefficients
     * @param trans an affine transform
     * @return the coefficients of the transformed conic
     */
    public final static double[] transform(double[] coefs,
            AffineTransform2D trans) {
        // Extract coefficients of the inverse transform
        double[][] mat = trans.invert().affineMatrix();
        double a = mat[0][0];
        double b = mat[1][0];
        double c = mat[0][1];
        double d = mat[1][1];
        double e = mat[0][2];
        double f = mat[1][2];

        // Extract conic coefficients
        double A = coefs[0];
        double B = coefs[1];
        double C = coefs[2];
        double D = coefs[3];
        double E = coefs[4];
        double F = coefs[5];

		// Compute coefficients of the transformed conic
		double A2 = A * a * a + B * a * b + C * b * b;
		double B2 = 2 * (A * a * c + C * b * d) + B * (a * d + b * c);
		double C2 = A * c * c + B * c * d + C * d * d;
		double D2 = 2 * (A * a * e + C * b * f) + B * (a * f + b * e) + D * a + E * b;
		double E2 = 2 * (A * c * e + C * d * f) + B * (c * f + d * e) + D * c + E * d;
		double F2 = A * e * e + B * e * f + C * f * f + D * e + E * f + F;

        // Return the array of coefficients
        return new double[] { A2, B2, C2, D2, E2, F2 };
    }

    
    public ArrayList<StraightLine2D> createCommonTangents(Conic2D conic1,Conic2D conic2){
       	ArrayList<StraightLine2D> tangents=new ArrayList<StraightLine2D>();
       	Conic2D conic= getDualConic( conic1,  conic2);
       	if (conic== null) return tangents;
    	Point2D[] pts=conic.getIntersections(conic2);
    	for  (int i=0;i<pts.length;i++){
    		double t = conic.project(pts[i]);
    		//Point2D p0 = conic.point(t);
    		// extract local tangent
    		Vector2D vect = CurveUtils.getTangentVector(conic, t);		
    		if(vect==null) {
    			continue;
    		}
      		// Compute the tangent line
    		tangents.add(new StraightLine2D(pts[i], vect));
    	}
    	
    	return tangents;
    }
    
    public static Conic2D getDualConic(Conic2D conic, Conic2D conicRef){
    	Point2D[] pts=new Point2D[5];
    	int i=0;
    	double[] x = new double[5];
    	double[] y = new double[5];
    	
    	for (double t=2;t<7; t++){
    		Point2D pt=getPole(conicRef, conic.getTangentAt_t(t));
      		if (pt==null)return null;
    		x[i]=pt.x;
    		y[i]=pt.y;
    		i++;
    	}

    	// Compute coefficients of the conic
		double[] coefs = findConicCoeff(x, y);
		if(coefs==null)
			return null;
		// Reduce coefficients to create the conic
		return Conics2D.reduceConic(coefs);
        
    }
    
	public final static double[] findConicCoeff(double[] x, double[] y) {
		
		// The array for storing the coefficients
		double[] res = new double[6];
		
		// First check there is no points on the same location
		for (int i = 1; i < 5; i++) {
			for (int j = 0; j < i; j++) {
				if ((x [i] == x [j]) && (y [i] == y [j])) {
					return null;
				}
			}
		}
		
		// allocate memory for first matrix
		double[][] mat = new double[5][6];

		// Create the first matrix
		for (int i=0; i<5; i++) {
			mat[i][0] = x[i] * x[i];
			mat[i][1] = x[i] * y[i];
			mat[i][2] = y[i] * y[i];
			mat[i][3] = x[i];
			mat[i][4] = y[i];
			mat[i][5] = 1;
		}
		
		// iterations
		//for(int iter=5; iter>=0; iter--) {
			int iter = 5;
			// the matrix and the vector to invert
			double[][] 	m = new double[5][5];
			double[] 	v = new double[5];
			
			// Initialize the matrix and the vector
			for (int i=0; i<5; i++)  {
				// The matrix
				for (int j=0; j<iter-1; j++)
					m[i][j] = mat[i][j];
				for (int j=iter-1; j<5; j++)
					m[i][j] = mat[i][j];
				
				// the vector
				v[i] = -mat[i][iter];
			}

			// Call the solver
			Matrix matrix = new Matrix(m);
			double[] coefs = matrix.solve(v);
		
//		    // Should do some test to check no pathological case
//		    if ((errno == 0) && (! det.petit ()))  {
//		      for (i = 0; i < iter - 1; i++)
//		        coeff [i] = u.readcoeff (i + 1);
//		      coeff [iter - 1] = N1;
//			for (i = iter; i <= 5; i++)
//			coeff [i] = u.readcoeff (i);
//			return TRUE;
//			}
			
			// format coefficients
			for (int i=0; i<iter; i++)
				res[i] = coefs[i];
			res [iter] = 1;
			for (int i=iter+1; i<=5; i++)
				res[i] = coefs[i-1];
		//} // end iter
		
		// return the computed coefficients
		return res;
	}
	
    public static Matrix33 createConicMatrix(Conic2D conic){
    	double[] coefs=conic.conicCoefficients();
    	double a = coefs[0];
        double b = coefs[1];
        double c = coefs[2];
        double d = coefs[3];
        double e = coefs[4];
        double f = coefs[5];
    	Matrix33 mat=new Matrix33(a,	b/2,	d/2,
    							  b/2,	c,		e/2,
    							  d/2,	e/2,	f);
    	return mat;
    }
    
    public static Conic2D createConicFromMatrix(Matrix33 mat){
    	double a =mat.m00;
        double b = 2*mat.m01;
        double c = mat.m11;
        double d = 2*mat.m02;
        double e = 2*mat.m12;
        double f = mat.m22;
    	return Conics2D.reduceConic(a, b, c, d, e, f);
    }
    // -----------------------------------------------------------------
    // Some special conics

       
	public static Point2D getPole(Conic2D conic, StraightLine2D line) {
		if (conic.conicType() == Conic2D.Type.NOT_A_CONIC
				|| conic.conicType() == Conic2D.Type.STRAIGHT_LINE
				|| conic.conicType() == Conic2D.Type.TWO_LINES)
			return null;

		Point2D p1 = line.point(0);
		Point2D p2 = line.point(1);

		// get coefficients from conic eqn
		double c[] = new double[6];
		c = conic.conicCoefficients();
		// applying T=0 for conic get the coefficient for equation of pole as
		// lx+my+n=0
		// Get first conjugate line wrt polar
		double h = p1.x;
		double k = p1.y;
		double l = c[0] * h + c[1] * k / 2 + c[3] / 2;
		double m = c[2] * k + c[1] * h / 2 + c[4] / 2;
		double n = c[3] * h / 2 + c[4] * k / 2 + c[5];
		StraightLine2D L1 = new StraightLine2D(l, m, n);
		// get secong conjugate line wrt polar
		h = p2.x;
		k = p2.y;
		l = c[0] * h + c[1] * k / 2 + c[3] / 2;
		m = c[2] * k + c[1] * h / 2 + c[4] / 2;
		n = c[3] * h / 2 + c[4] * k / 2 + c[5];
		StraightLine2D L2 = new StraightLine2D(l, m, n);
		// Solve 2 conjugate lines to get pole
		return L1.intersection(L2);
	}
      // TODO: add CrossConic2D
}
